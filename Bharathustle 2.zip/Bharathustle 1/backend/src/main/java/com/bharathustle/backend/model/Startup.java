package com.bharathustle.backend.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Startup {
    private Long id;
    private String name;
    private String category;
    private String description;
    private String mrr;
    private String totalRevenue;
    private String growth;
    private String askingPrice;
    private String website;
    private String founderName;
    private String location;
    private String logoLetter;
    private String logoColor;
    private List<String> tags;
    private List<Double> sparkline;
    private Boolean isFeatured;
    private Boolean isRanked;
    private Integer rank;
    private LocalDateTime createdAt;
}
