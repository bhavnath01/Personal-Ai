package com.bharathustle.backend.service;

import com.bharathustle.backend.dto.AuthRequest;
import com.bharathustle.backend.dto.AuthResponse;
import com.bharathustle.backend.dto.UserDTO;
import com.bharathustle.backend.model.User;
import com.bharathustle.backend.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {
    private final UserRepository userRepository;

    public AuthService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public AuthResponse login(AuthRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found with email: " + request.getEmail()));

        // In production, use BCrypt.checkPassword(request.getPassword(), user.getPasswordHash())
        if (!user.getPasswordHash().equals(request.getPassword())) {
            throw new RuntimeException("Invalid password");
        }

        return AuthResponse.builder()
                .token("mock-jwt-token-" + user.getId())
                .user(mapToDTO(user))
                .build();
    }

    public UserDTO signup(User user) {
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            throw new RuntimeException("Email already in use: " + user.getEmail());
        }
        
        // In production, user.setPasswordHash(BCrypt.hash(user.getPasswordHash()))
        userRepository.save(user);
        
        return mapToDTO(userRepository.findByEmail(user.getEmail()).get());
    }

    private UserDTO mapToDTO(User user) {
        return UserDTO.builder()
                .id(user.getId().toString())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .initials(getInitials(user.getFullName()))
                .build();
    }

    private String getInitials(String fullName) {
        if (fullName == null || fullName.isBlank()) return "?";
        String[] parts = fullName.trim().split("\\s+");
        if (parts.length == 1) return parts[0].substring(0, 1).toUpperCase();
        return (parts[0].substring(0, 1) + parts[parts.length - 1].substring(0, 1)).toUpperCase();
    }
}
