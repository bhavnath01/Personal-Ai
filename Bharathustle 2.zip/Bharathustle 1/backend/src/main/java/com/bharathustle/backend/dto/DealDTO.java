package com.bharathustle.backend.dto;
import lombok.*;
import java.util.List;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class DealDTO {
    private Long id;
    private String tag;
    private String name;
    private String description;
    private String detail;
    private String mrr;
    private String askingPrice;
    private String growth;
    private String iconLetter;
    private String iconColor;
    private List<Double> sparkline;
}
