package com.bharathustle.backend.service;

import com.bharathustle.backend.dto.DealDTO;
import com.bharathustle.backend.model.Deal;
import com.bharathustle.backend.repository.DealRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DealService {
    private final DealRepository dealRepository;

    public DealService(DealRepository dealRepository) {
        this.dealRepository = dealRepository;
    }

    public List<DealDTO> getAllDeals() {
        return dealRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public DealDTO getFeaturedDeal() {
        return dealRepository.findFeatured()
                .map(this::convertToDTO)
                .orElseThrow(() -> new RuntimeException("No featured deal found"));
    }

    public DealDTO getDealById(Long id) {
        return dealRepository.findById(id)
                .map(this::convertToDTO)
                .orElseThrow(() -> new RuntimeException("Deal not found with id: " + id));
    }

    private DealDTO convertToDTO(Deal deal) {
        return DealDTO.builder()
                .id(deal.getId())
                .tag(deal.getTag())
                .name(deal.getName())
                .description(deal.getDescription())
                .detail(deal.getDetail())
                .mrr(deal.getMrr())
                .askingPrice(deal.getAskingPrice())
                .growth(deal.getGrowth())
                .iconLetter(deal.getIconLetter())
                .iconColor(deal.getIconColor())
                .sparkline(deal.getSparkline())
                .build();
    }
}
