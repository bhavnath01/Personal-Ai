package com.bharathustle.backend.repository;

import com.bharathustle.backend.model.User;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public class UserRepository {
    private final JdbcTemplate jdbcTemplate;

    public UserRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<User> userRowMapper = (rs, rowNum) -> User.builder()
            .id(rs.getObject("id", UUID.class))
            .fullName(rs.getString("full_name"))
            .email(rs.getString("email"))
            .passwordHash(rs.getString("password_hash"))
            .createdAt(rs.getTimestamp("created_at").toLocalDateTime())
            .build();

    public Optional<User> findByEmail(String email) {
        String sql = "SELECT id, full_name, email, password_hash, created_at FROM users WHERE email = ?";
        return jdbcTemplate.query(sql, userRowMapper, email).stream().findFirst();
    }

    public int save(User user) {
        String sql = "INSERT INTO users (full_name, email, password_hash) VALUES (?, ?, ?)";
        return jdbcTemplate.update(sql, user.getFullName(), user.getEmail(), user.getPasswordHash());
    }
}
