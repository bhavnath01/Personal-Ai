package com.bharathustle.backend.dto;
import lombok.*;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class UserDTO {
    private String id;
    private String fullName;
    private String email;
    private String initials;
}
