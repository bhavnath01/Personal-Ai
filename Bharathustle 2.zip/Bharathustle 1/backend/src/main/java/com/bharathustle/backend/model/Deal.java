package com.bharathustle.backend.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Deal {
    private Long id;
    private String tag;
    private String name;
    private String description;
    private String detail;
    private String mrr;
    private String askingPrice;
    private String growth;
    private String iconLetter;
    private String iconColor;
    private List<Double> sparkline;
    private LocalDateTime createdAt;
}
