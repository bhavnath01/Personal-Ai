package com.bharathustle.backend.service;

import com.bharathustle.backend.dto.StartupDTO;
import com.bharathustle.backend.model.Startup;
import com.bharathustle.backend.repository.StartupRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class StartupService {
    private final StartupRepository startupRepository;

    public StartupService(StartupRepository startupRepository) {
        this.startupRepository = startupRepository;
    }

    public List<StartupDTO> getAllStartups() {
        return startupRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public StartupDTO getStartupById(Long id) {
        return startupRepository.findById(id)
                .map(this::convertToDTO)
                .orElseThrow(() -> new RuntimeException("Startup not found with id: " + id));
    }

    public List<StartupDTO> searchStartups(String query) {
        if (query == null || query.isBlank()) {
            return getAllStartups();
        }
        return startupRepository.search(query).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public void createStartup(StartupDTO dto) {
        validateStartup(dto);
        Startup startup = convertToEntity(dto);
        startupRepository.insert(startup);
    }

    private void validateStartup(StartupDTO dto) {
        if (dto.getName() == null || dto.getName().isBlank()) {
            throw new RuntimeException("Startup name is required");
        }
        if (dto.getAskingPrice() == null || dto.getAskingPrice().isBlank()) {
            throw new RuntimeException("Asking price is required");
        }
    }

    private StartupDTO convertToDTO(Startup startup) {
        return StartupDTO.builder()
                .id(startup.getId())
                .name(startup.getName())
                .category(startup.getCategory())
                .description(startup.getDescription())
                .mrr(startup.getMrr())
                .totalRevenue(startup.getTotalRevenue())
                .growth(startup.getGrowth())
                .askingPrice(startup.getAskingPrice())
                .founderName(startup.getFounderName())
                .location(startup.getLocation())
                .logoLetter(startup.getLogoLetter())
                .logoColor(startup.getLogoColor())
                .tags(startup.getTags())
                .sparkline(startup.getSparkline())
                .isFeatured(startup.getIsFeatured())
                .isRanked(startup.getIsRanked())
                .rank(startup.getRank())
                .build();
    }

    private Startup convertToEntity(StartupDTO dto) {
        return Startup.builder()
                .name(dto.getName())
                .category(dto.getCategory())
                .description(dto.getDescription())
                .mrr(dto.getMrr())
                .totalRevenue(dto.getTotalRevenue())
                .growth(dto.getGrowth())
                .askingPrice(dto.getAskingPrice())
                .website(dto.getWebsite())
                .founderName(dto.getFounderName())
                .location(dto.getLocation())
                .logoLetter(dto.getLogoLetter())
                .logoColor(dto.getLogoColor())
                .tags(dto.getTags())
                .sparkline(dto.getSparkline())
                .isFeatured(dto.getIsFeatured() != null ? dto.getIsFeatured() : false)
                .isRanked(dto.getIsRanked() != null ? dto.getIsRanked() : false)
                .rank(dto.getRank())
                .build();
    }
}
