package com.bharathustle.backend.repository;

import com.bharathustle.backend.model.Deal;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.Array;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Repository
public class DealRepository {
    private final JdbcTemplate jdbcTemplate;

    public DealRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Deal> dealRowMapper = (rs, rowNum) -> {
        Deal deal = Deal.builder()
                .id(rs.getLong("id"))
                .tag(rs.getString("tag"))
                .name(rs.getString("name"))
                .description(rs.getString("description"))
                .detail(rs.getString("detail"))
                .mrr(rs.getString("mrr"))
                .askingPrice(rs.getString("asking_price"))
                .growth(rs.getString("growth"))
                .iconLetter(rs.getString("icon_letter"))
                .iconColor(rs.getString("icon_color"))
                .createdAt(rs.getTimestamp("created_at").toLocalDateTime())
                .build();

        Array sparkArray = rs.getArray("sparkline");
        if (sparkArray != null) {
            deal.setSparkline(Arrays.asList((Double[]) sparkArray.getArray()));
        }

        return deal;
    };

    public List<Deal> findAll() {
        String sql = "SELECT * FROM deals ORDER BY created_at DESC";
        return jdbcTemplate.query(sql, dealRowMapper);
    }

    public Optional<Deal> findById(Long id) {
        String sql = "SELECT * FROM deals WHERE id = ?";
        return jdbcTemplate.query(sql, dealRowMapper, id).stream().findFirst();
    }

    public Optional<Deal> findFeatured() {
        String sql = "SELECT * FROM deals WHERE tag = 'PREMIUM ASSET' LIMIT 1";
        return jdbcTemplate.query(sql, dealRowMapper).stream().findFirst();
    }
}
