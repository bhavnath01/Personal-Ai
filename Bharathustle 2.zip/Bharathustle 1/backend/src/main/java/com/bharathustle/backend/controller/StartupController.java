package com.bharathustle.backend.controller;

import com.bharathustle.backend.dto.StartupDTO;
import com.bharathustle.backend.service.StartupService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/startups")
@CrossOrigin(origins = "*")
public class StartupController {

    private final StartupService startupService;

    public StartupController(StartupService startupService) {
        this.startupService = startupService;
    }

    @GetMapping
    public ResponseEntity<List<StartupDTO>> getAllStartups(@RequestParam(required = false) String query) {
        if (query != null && !query.isBlank()) {
            return ResponseEntity.ok(startupService.searchStartups(query));
        }
        return ResponseEntity.ok(startupService.getAllStartups());
    }

    @GetMapping("/{id}")
    public ResponseEntity<StartupDTO> getStartupById(@PathVariable Long id) {
        return ResponseEntity.ok(startupService.getStartupById(id));
    }

    @PostMapping
    public ResponseEntity<Void> createStartup(@RequestBody StartupDTO startupDTO) {
        startupService.createStartup(startupDTO);
        return ResponseEntity.ok().build();
    }
}
