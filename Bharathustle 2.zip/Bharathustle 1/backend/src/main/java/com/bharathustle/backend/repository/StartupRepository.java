package com.bharathustle.backend.repository;

import com.bharathustle.backend.model.Startup;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.Array;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Repository
public class StartupRepository {
    private final JdbcTemplate jdbcTemplate;

    public StartupRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Startup> startupRowMapper = (rs, rowNum) -> {
        Startup startup = Startup.builder()
                .id(rs.getLong("id"))
                .name(rs.getString("name"))
                .category(rs.getString("category"))
                .description(rs.getString("description"))
                .mrr(rs.getString("mrr"))
                .totalRevenue(rs.getString("total_revenue"))
                .growth(rs.getString("growth"))
                .askingPrice(rs.getString("asking_price"))
                .website(hasColumn(rs, "website") ? rs.getString("website") : "")
                .founderName(rs.getString("founder_name"))
                .location(rs.getString("location"))
                .logoLetter(rs.getString("logo_letter"))
                .logoColor(rs.getString("logo_color"))
                .isFeatured(rs.getBoolean("is_featured"))
                .isRanked(rs.getBoolean("is_ranked"))
                .rank(rs.getObject("rank", Integer.class))
                .createdAt(rs.getTimestamp("created_at").toLocalDateTime())
                .build();

        Array tagsArray = rs.getArray("tags");
        if (tagsArray != null) {
            startup.setTags(Arrays.asList((String[]) tagsArray.getArray()));
        }

        Array sparkArray = rs.getArray("sparkline");
        if (sparkArray != null) {
            startup.setSparkline(Arrays.asList((Double[]) sparkArray.getArray()));
        }

        return startup;
    };

    public List<Startup> findAll() {
        String sql = "SELECT * FROM startups ORDER BY created_at DESC";
        return jdbcTemplate.query(sql, startupRowMapper);
    }

    public Optional<Startup> findById(Long id) {
        String sql = "SELECT * FROM startups WHERE id = ?";
        return jdbcTemplate.query(sql, startupRowMapper, id).stream().findFirst();
    }

    public List<Startup> search(String query) {
        String sql = "SELECT * FROM startups WHERE LOWER(name) LIKE LOWER(?) OR LOWER(category) LIKE LOWER(?) OR LOWER(description) LIKE LOWER(?)";
        String searchParam = "%" + query + "%";
        return jdbcTemplate.query(sql, startupRowMapper, searchParam, searchParam, searchParam);
    }

    public int insert(Startup startup) {
        String sql = "INSERT INTO startups (name, category, description, mrr, total_revenue, growth, asking_price, website, " +
                     "founder_name, location, logo_letter, logo_color, tags, sparkline, is_featured, is_ranked, rank) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        return jdbcTemplate.execute((Connection conn) -> {
            try (var ps = conn.prepareStatement(sql)) {
                ps.setString(1, startup.getName());
                ps.setString(2, startup.getCategory());
                ps.setString(3, startup.getDescription());
                ps.setString(4, startup.getMrr());
                ps.setString(5, startup.getTotalRevenue());
                ps.setString(6, startup.getGrowth());
                ps.setString(7, startup.getAskingPrice());
                ps.setString(8, startup.getWebsite());
                ps.setString(9, startup.getFounderName());
                ps.setString(10, startup.getLocation());
                ps.setString(11, startup.getLogoLetter());
                ps.setString(12, startup.getLogoColor());
                
                Array tagsArray = conn.createArrayOf("text", startup.getTags() != null ? startup.getTags().toArray(new String[0]) : new String[0]);
                ps.setArray(13, tagsArray);
                
                Array sparkArray = conn.createArrayOf("float8", startup.getSparkline() != null ? startup.getSparkline().toArray(new Double[0]) : new Double[0]);
                ps.setArray(14, sparkArray);
                
                ps.setBoolean(15, startup.getIsFeatured() != null ? startup.getIsFeatured() : false);
                ps.setBoolean(16, startup.getIsRanked() != null ? startup.getIsRanked() : false);
                
                if (startup.getRank() != null) {
                    ps.setInt(17, startup.getRank());
                } else {
                    ps.setNull(17, java.sql.Types.INTEGER);
                }
                
                return ps.executeUpdate();
            } catch (SQLException e) {
                // If column "website" is missing (PostgreSQL error 42703), try to add it and retry once
                if ("42703".equals(e.getSQLState()) && e.getMessage().contains("website")) {
                    try (var stmt = conn.createStatement()) {
                        stmt.execute("ALTER TABLE startups ADD COLUMN website VARCHAR(255)");
                        // Retry the insertion
                        try (var psRetry = conn.prepareStatement(sql)) {
                            psRetry.setString(1, startup.getName());
                            psRetry.setString(2, startup.getCategory());
                            psRetry.setString(3, startup.getDescription());
                            psRetry.setString(4, startup.getMrr());
                            psRetry.setString(5, startup.getTotalRevenue());
                            psRetry.setString(6, startup.getGrowth());
                            psRetry.setString(7, startup.getAskingPrice());
                            psRetry.setString(8, startup.getWebsite());
                            psRetry.setString(9, startup.getFounderName());
                            psRetry.setString(10, startup.getLocation());
                            psRetry.setString(11, startup.getLogoLetter());
                            psRetry.setString(12, startup.getLogoColor());
                            psRetry.setArray(13, conn.createArrayOf("text", startup.getTags() != null ? startup.getTags().toArray(new String[0]) : new String[0]));
                            psRetry.setArray(14, conn.createArrayOf("float8", startup.getSparkline() != null ? startup.getSparkline().toArray(new Double[0]) : new Double[0]));
                            psRetry.setBoolean(15, startup.getIsFeatured() != null ? startup.getIsFeatured() : false);
                            psRetry.setBoolean(16, startup.getIsRanked() != null ? startup.getIsRanked() : false);
                            if (startup.getRank() != null) psRetry.setInt(17, startup.getRank());
                            else psRetry.setNull(17, java.sql.Types.INTEGER);
                            return psRetry.executeUpdate();
                        }
                    } catch (SQLException ex) {
                        throw new RuntimeException("Failed to auto-add 'website' column and retry", ex);
                    }
                }
                throw new RuntimeException("Error inserting startup into PostgreSQL", e);
            }
        });
    }

    private boolean hasColumn(java.sql.ResultSet rs, String columnName) throws java.sql.SQLException {
        java.sql.ResultSetMetaData rsmd = rs.getMetaData();
        int columns = rsmd.getColumnCount();
        for (int x = 1; x <= columns; x++) {
            if (columnName.equalsIgnoreCase(rsmd.getColumnName(x))) {
                return true;
            }
        }
        return false;
    }
}
