package com.bharathustle.backend.controller;

import com.bharathustle.backend.dto.AuthRequest;
import com.bharathustle.backend.dto.AuthResponse;
import com.bharathustle.backend.dto.UserDTO;
import com.bharathustle.backend.model.User;
import com.bharathustle.backend.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {
    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody AuthRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }

    @PostMapping("/signup")
    public ResponseEntity<UserDTO> signup(@RequestBody User user) {
        return ResponseEntity.status(HttpStatus.CREATED).body(authService.signup(user));
    }
}
