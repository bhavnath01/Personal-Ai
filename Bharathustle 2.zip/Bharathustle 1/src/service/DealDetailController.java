package service;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Polyline;
import model.DealModel;
import java.util.Collections;
import java.util.List;

public class DealDetailController {

    @FXML private Button backButton;
    @FXML private StackPane tagBadge;
    @FXML private Label tagLabel;
    @FXML private StackPane iconBox;
    @FXML private Label iconText;
    @FXML private Label startupNameLabel;
    @FXML private Label detailLabel;
    @FXML private Label priceLabel;
    @FXML private Label mrrLabel;
    @FXML private Label growthLabel;
    @FXML private Label descriptionLabel;
    @FXML private Pane graphPane;
    @FXML private Polyline graphLine;
    @FXML private Button ctaButton;

    private DealModel deal;
    private NavigationManager navigationManager;

    public void setNavigationManager(NavigationManager navManager) {
        this.navigationManager = navManager;
        backButton.setOnAction(e -> handleBack());
        ctaButton.setOnAction(e -> handleCTA());
    }

    public void setDealData(int dealId) {
        this.deal = StartupService.getInstance().getDealById(dealId);
        if (deal != null) populateData();
    }

    private void populateData() {
        tagLabel.setText(deal.getTag());
        iconText.setText(deal.getIcon());
        startupNameLabel.setText(deal.getName());
        detailLabel.setText(deal.getDetail());
        priceLabel.setText(deal.getAskingPrice());
        mrrLabel.setText(deal.getMrr());
        growthLabel.setText(deal.getGrowth());
        descriptionLabel.setText(deal.getDescription());

        growthLabel.getStyleClass().removeAll("positive-growth", "negative-growth");
        growthLabel.getStyleClass().add(deal.getGrowth().startsWith("-") ? "negative-growth" : "positive-growth");

        tagBadge.setStyle(
            "-fx-background-color: rgba(115,23,23,0.38);"
            + "-fx-border-color: rgba(226,67,67,0.75);"
            + "-fx-border-width:1;"
            + "-fx-background-radius:18;"
            + "-fx-border-radius:18;");

        iconBox.setStyle("-fx-background-color: " + deal.getIconColor() + "; -fx-background-radius: 40;");
        drawGraph(deal.getSparkline());
    }

    private void drawGraph(List<Double> values) {
        graphLine.getPoints().clear();
        if (values == null || values.size() < 2) return;

        double w = 940.0;
        double h = 100.0;
        double min = Collections.min(values);
        double max = Collections.max(values);
        double range = Math.max(0.0001, max - min);

        for (int i = 0; i < values.size(); i++) {
            double x = (w / (values.size() - 1)) * i;
            double norm = (values.get(i) - min) / range;
            double y = h - (norm * (h - 16)) - 8;
            graphLine.getPoints().addAll(x, y);
        }
    }

    private void handleBack() {
        if (navigationManager != null && navigationManager.canGoBack()) {
            navigationManager.goBack();
        }
    }

    private void handleCTA() {
        // Mock action — show an alert or navigate
    }
}