package service;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import model.StartupModel;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class FindStartupsController {

    @FXML private Button backButton;
    @FXML private TextField searchField;
    @FXML private ComboBox<String> categoryFilter;
    @FXML private TextField revenueMin;
    @FXML private TextField revenueMax;
    @FXML private TextField mrrMin;
    @FXML private TextField mrrMax;
    @FXML private TextField growthMin;
    @FXML private TextField growthMax;
    @FXML private TextField priceMin;
    @FXML private TextField priceMax;
    @FXML private ComboBox<String> multipleFilter;
    @FXML private ComboBox<String> audienceFilter;
    @FXML private ComboBox<String> listedFilter;
    @FXML private Button applyFiltersButton;
    @FXML private Button resetFiltersButton;
    @FXML private Label resultCountLabel;
    @FXML private ComboBox<String> sortCombo;
    @FXML private FlowPane cardsContainer;

    private NavigationManager navigationManager;
    private List<StartupModel> allStartups;
    private String initialQuery = "";

    @FXML
    public void initialize() {
        categoryFilter.setItems(FXCollections.observableArrayList(
            "All", "SaaS", "AI / ML", "Fintech", "E-commerce",
            "HealthTech", "DevTools", "No-code Tools", "Automation", "EdTech", "MarTech"
        ));
        multipleFilter.setItems(FXCollections.observableArrayList(
            "Any multiple", "Under 1x", "1x – 2x", "2x – 3x", "3x – 5x", "5x+"
        ));
        audienceFilter.setItems(FXCollections.observableArrayList(
            "Any", "B2B", "B2C", "B2B2C", "Developer"
        ));
        listedFilter.setItems(FXCollections.observableArrayList(
            "Any time", "Last 24 hours", "Last 7 days", "Last 30 days"
        ));
        sortCombo.setItems(FXCollections.observableArrayList(
            "Best deals (default)", "Highest MRR", "Lowest price", "Highest growth", "Newest listed"
        ));
        sortCombo.setValue("Best deals (default)");

        applyFiltersButton.setOnAction(e -> applyFilters());
        resetFiltersButton.setOnAction(e -> resetFilters());
        searchField.textProperty().addListener((obs, o, n) -> applyFilters());
        sortCombo.setOnAction(e -> applyFilters());

        backButton.setOnAction(e -> {
            if (navigationManager != null) navigationManager.goBack();
        });
    }

    public void setNavigationManager(NavigationManager nm) {
        this.navigationManager = nm;
    }

    public void setInitialQuery(String query) {
        this.initialQuery = query == null ? "" : query;
        if (searchField != null) searchField.setText(initialQuery);
    }

    public void loadStartups() {
        allStartups = StartupService.getInstance().getAllStartups();
        applyFilters();
    }

    private void applyFilters() {
        if (allStartups == null) return;

        String query = searchField.getText() == null ? "" : searchField.getText().trim().toLowerCase(Locale.US);
        String cat = categoryFilter.getValue();

        List<StartupModel> filtered = allStartups.stream().filter(s -> {
            // text match
            if (!query.isBlank()) {
                String searchable = (s.getName() + " " + s.getCategory() + " " + s.getDescription()).toLowerCase(Locale.US);
                if (!searchable.contains(query)) return false;
            }
            // category
            if (cat != null && !cat.equals("All") && !cat.isBlank()) {
                if (!s.getCategory().toLowerCase(Locale.US).contains(cat.toLowerCase(Locale.US))) return false;
            }
            return true;
        }).collect(Collectors.toList());

        // Sort
        String sort = sortCombo.getValue();
        if (sort != null) {
            if (sort.contains("Highest MRR")) {
                filtered.sort((a, b) -> b.getMrr().compareTo(a.getMrr()));
            } else if (sort.contains("Lowest price")) {
                filtered.sort((a, b) -> a.getAskingPrice().compareTo(b.getAskingPrice()));
            } else if (sort.contains("Highest growth")) {
                filtered.sort((a, b) -> b.getGrowth().compareTo(a.getGrowth()));
            }
        }

        renderCards(filtered);
        resultCountLabel.setText(filtered.size() + " startups found");
    }

    private void resetFilters() {
        searchField.clear();
        categoryFilter.setValue(null);
        multipleFilter.setValue(null);
        audienceFilter.setValue(null);
        listedFilter.setValue(null);
        revenueMin.clear(); revenueMax.clear();
        mrrMin.clear(); mrrMax.clear();
        growthMin.clear(); growthMax.clear();
        priceMin.clear(); priceMax.clear();
        applyFilters();
    }

    private void renderCards(List<StartupModel> startups) {
        cardsContainer.getChildren().clear();
        for (StartupModel s : startups) {
            VBox card = buildCard(s);
            cardsContainer.getChildren().add(card);
        }
    }

    private VBox buildCard(StartupModel s) {
        VBox card = new VBox(16); // Increased spacing
        card.getStyleClass().add("fs-startup-card");
        card.setPrefWidth(340); // Slightly wider to give breathing room
        card.setMaxWidth(340);
        card.setCursor(Cursor.HAND);
        card.setPadding(new javafx.geometry.Insets(20, 20, 20, 20));

        // Parse dynamic color
        javafx.scene.paint.Color c;
        try {
            c = javafx.scene.paint.Color.web(s.getLogoColor());
        } catch(Exception e) {
            c = javafx.scene.paint.Color.web("#22c55e");
        }
        int r = (int)(c.getRed() * 255);
        int g = (int)(c.getGreen() * 255);
        int b = (int)(c.getBlue() * 255);
        
        String rgbaBase = String.format("rgba(%d, %d, %d, 0.05)", r, g, b);
        String rgbaHover = String.format("rgba(%d, %d, %d, 0.14)", r, g, b);
        String rgbaBorder = String.format("rgba(%d, %d, %d, 0.35)", r, g, b);
        String rgbaGlow = String.format("rgba(%d, %d, %d, 0.25)", r, g, b);

        String defaultStyle = "-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #121821 40%, " + rgbaBase + " 100%); " +
                              "-fx-border-color: rgba(255, 255, 255, 0.06); " +
                              "-fx-border-width: 1; " +
                              "-fx-background-radius: 16; " +
                              "-fx-border-radius: 16;";
                              
        String hoverStyle = "-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #151d28 30%, " + rgbaHover + " 100%); " +
                            "-fx-border-color: " + rgbaBorder + "; " +
                            "-fx-border-width: 1; " +
                            "-fx-background-radius: 16; " +
                            "-fx-border-radius: 16; " +
                            "-fx-effect: dropshadow(gaussian, " + rgbaGlow + ", 24, 0.15, 0, 8);";

        card.setStyle(defaultStyle);

        // ── Header row: logo + name + category badge
        HBox header = new HBox(12);
        header.setAlignment(Pos.CENTER_LEFT);

        StackPane logo = new StackPane();
        logo.getStyleClass().add("fs-card-logo");
        logo.setPrefSize(44, 44);
        logo.setMinSize(44, 44);
        logo.setStyle("-fx-background-color: " + s.getLogoColor() + "; -fx-background-radius: 10;");
        Label logoLetter = new Label(s.getLogoLetter());
        logoLetter.getStyleClass().add("fs-card-logo-text");
        logo.getChildren().add(logoLetter);

        VBox nameBox = new VBox(4);
        nameBox.setAlignment(Pos.CENTER_LEFT);
        Label name = new Label(s.getName());
        name.getStyleClass().add("fs-card-name");
        StackPane catBadge = new StackPane();
        catBadge.getStyleClass().add("fs-card-cat-badge");
        Label catLabel = new Label(s.getCategory());
        catLabel.getStyleClass().add("fs-card-cat-text");
        catBadge.getChildren().add(catLabel);
        nameBox.getChildren().addAll(name, catBadge);

        header.getChildren().addAll(logo, nameBox);
        header.getChildren().add(new Region() {{ HBox.setHgrow(this, javafx.scene.layout.Priority.ALWAYS); }});

        // ── Description
        Label desc = new Label(s.getDescription());
        desc.getStyleClass().add("fs-card-desc");
        desc.setWrapText(true);
        desc.setMaxWidth(300);
        desc.setMinHeight(36);
        desc.setMaxHeight(36); // Clamp to roughly 2 lines
        desc.setAlignment(Pos.TOP_LEFT);

        // ── Metrics row
        HBox metrics = new HBox(0);
        metrics.getStyleClass().add("fs-card-metrics");
        metrics.setAlignment(Pos.CENTER_LEFT);
        metrics.setPadding(new javafx.geometry.Insets(14, 0, 0, 0));

        VBox revBox = buildMetric("REVENUE (30D)", s.getMrr());
        VBox priceBox = buildMetric("ASKING PRICE", s.getAskingPrice());
        VBox growthBox = buildMetric("GROWTH", s.getGrowth());

        Region r1 = new Region(); HBox.setHgrow(r1, javafx.scene.layout.Priority.ALWAYS);
        Region r2 = new Region(); HBox.setHgrow(r2, javafx.scene.layout.Priority.ALWAYS);

        metrics.getChildren().addAll(revBox, r1, priceBox, r2, growthBox);

        card.getChildren().addAll(header, desc, metrics);
        card.setOnMouseClicked(e -> {
            if (navigationManager != null) {
                navigationManager.goToStartupDetail(s.getId());
            }
        });

        // Dynamic hover animation using the computed styles
        card.setOnMouseEntered(ev -> card.setStyle(hoverStyle));
        card.setOnMouseExited(ev -> card.setStyle(defaultStyle));

        return card;
    }

    private VBox buildMetric(String label, String value) {
        VBox box = new VBox(3);
        Label lbl = new Label(label);
        lbl.getStyleClass().add("fs-metric-label");
        Label val = new Label(value == null ? "—" : value);
        val.getStyleClass().add("fs-metric-value");
        box.getChildren().addAll(lbl, val);
        return box;
    }
}
