package service;

import javafx.animation.FadeTransition;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;

public class NavigationManager {
    private static NavigationManager instance;
    private final StackPane viewContainer;
    private final Deque<Node> viewHistory = new ArrayDeque<>();
    private Node currentView;

    private NavigationManager(StackPane container) {
        this.viewContainer = container;
    }

    public static NavigationManager getInstance() {
        return instance;
    }

    public static void initialize(StackPane container) {
        instance = new NavigationManager(container);
    }

    public void goToStartupDetail(int startupId) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/StartupDetailView.fxml"));
            Node view = loader.load();
            StartupDetailController controller = loader.getController();
            controller.setStartupData(startupId);
            controller.setNavigationManager(this);
            transitionToView(view);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void goToDealDetail(int dealId) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/DealDetailView.fxml"));
            Node view = loader.load();
            DealDetailController controller = loader.getController();
            controller.setDealData(dealId);
            controller.setNavigationManager(this);
            transitionToView(view);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void goToFindStartups(String query) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/FindStartupsView.fxml"));
            Node view = loader.load();
            FindStartupsController controller = loader.getController();
            controller.setNavigationManager(this);
            controller.setInitialQuery(query);
            controller.loadStartups();
            transitionToView(view);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void goToHowItWorks() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/HowItWorksView.fxml"));
            Node view = loader.load();
            transitionToView(view);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void goToTestimonials() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/TestimonialsView.fxml"));
            Node view = loader.load();
            transitionToView(view);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void goToAuth() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/AuthView.fxml"));
            Node view = loader.load();
            transitionToView(view);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void goToHome(Node homeView) {
        if (currentView != null) {
            viewHistory.clear();
        }
        transitionToView(homeView);
    }

    public void goBack() {
        if (!viewHistory.isEmpty()) {
            Node previousView = viewHistory.pop();
            currentView = null; // prevent transitionToView from re-pushing

            previousView.setOpacity(0.0);
            viewContainer.getChildren().clear();
            viewContainer.getChildren().add(previousView);

            FadeTransition fade = new FadeTransition(Duration.millis(220), previousView);
            fade.setFromValue(0.0);
            fade.setToValue(1.0);
            fade.play();

            currentView = previousView;
        }
    }

    public boolean canGoBack() {
        return !viewHistory.isEmpty();
    }

    private void transitionToView(Node newView) {
        if (currentView != null) {
            viewHistory.push(currentView);
        }

        newView.setOpacity(0.0);
        viewContainer.getChildren().clear();
        viewContainer.getChildren().add(newView);

        FadeTransition fade = new FadeTransition(Duration.millis(250), newView);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        fade.play();

        currentView = newView;
    }

    public StackPane getViewContainer() {
        return viewContainer;
    }
}