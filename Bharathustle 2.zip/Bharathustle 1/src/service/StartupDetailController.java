package service;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polyline;
import javafx.util.Duration;
import model.StartupModel;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class StartupDetailController {

    @FXML private Button backButton;
    @FXML private Button shareButton;
    @FXML private Button visitButton;
    @FXML private StackPane logoBox;
    @FXML private Label logoText;
    @FXML private Label startupNameLabel;
    @FXML private Label categoryLabel;
    @FXML private Label locationLabel;
    @FXML private Label descriptionLabel;
    @FXML private Label priceLabel;
    @FXML private Label mrrLabel;
    @FXML private Label totalRevenueLabel;
    @FXML private Label growthLabel;
    @FXML private Label founderMetricLabel;
    @FXML private Pane graphPane;
    @FXML private Polyline graphLine;
    @FXML private Label insightValueProp;
    @FXML private Label insightAudience;
    @FXML private Label insightPricing;
    @FXML private StackPane founderBadge;
    @FXML private Label founderInitial;
    @FXML private Label founderNameLabel;
    @FXML private Label founderLocationLabel;
    @FXML private FlowPane tagsContainer;
    @FXML private Canvas activityCanvas;

    private StartupModel startup;
    private NavigationManager navigationManager;

    private static final String[] INSIGHTS_VALUE = {
        "Automates manual processes saving hours per week",
        "AI-powered analytics with predictive accuracy",
        "Real-time financial compliance with zero manual work",
        "No-code builder that anyone can use in minutes",
        "Intelligent lead scoring reduces churn by 30%",
        "Comprehensive health monitoring for proactive care"
    };
    private static final String[] INSIGHTS_AUDIENCE = {
        "SMBs and enterprise operations teams",
        "Data-driven product and growth teams",
        "CFOs, finance controllers, and accountants",
        "Non-technical founders and marketing teams",
        "B2B sales teams of 5-50 reps",
        "Clinics, hospitals, and individual health-conscious users"
    };
    private static final String[] INSIGHTS_PRICING = {
        "SaaS subscription, $49-$299/mo per seat",
        "Usage-based pricing + enterprise tier",
        "Annual contracts with volume discounts",
        "Freemium with pro plan at $19/mo",
        "Per-seat pricing, average $89/mo",
        "B2C $9/mo; B2B custom pricing"
    };
    private static final String[] TECH_STACKS = {
        "React, Node.js, PostgreSQL, Redis, AWS",
        "Python, FastAPI, TensorFlow, BigQuery",
        "Java Spring, Kafka, MySQL, Docker",
        "Vue.js, Firebase, Stripe, Tailwind",
        "Next.js, TypeScript, Supabase, Vercel",
        "React Native, GraphQL, MongoDB, GCP"
    };

    public void setNavigationManager(NavigationManager navManager) {
        this.navigationManager = navManager;
        backButton.setOnAction(e -> handleBack());
        shareButton.setOnAction(e -> {});
        visitButton.setOnAction(e -> {
            if (startup != null && startup.getWebsite() != null && !startup.getWebsite().isBlank()) {
                try {
                    String url = startup.getWebsite();
                    if (!url.startsWith("http://") && !url.startsWith("https://")) {
                        url = "https://" + url;
                    }
                    java.awt.Desktop.getDesktop().browse(new java.net.URI(url));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    public void setStartupData(int startupId) {
        this.startup = StartupService.getInstance().getStartupById(startupId);
        if (startup != null) populateData();
    }

    private void populateData() {
        int idx = Math.max(0, (startup.getId() - 1) % INSIGHTS_VALUE.length);

        logoText.setText(startup.getLogoLetter());
        startupNameLabel.setText(startup.getName());
        categoryLabel.setText(startup.getCategory());
        locationLabel.setText("📍 " + startup.getLocation());
        descriptionLabel.setText(startup.getDescription());
        priceLabel.setText(startup.getAskingPrice());
        mrrLabel.setText(startup.getMrr());
        totalRevenueLabel.setText(startup.getTotalRevenue());
        founderMetricLabel.setText(startup.getFounder());
        founderNameLabel.setText(startup.getFounder());
        founderLocationLabel.setText(startup.getLocation());

        String growth = startup.getGrowth();
        growthLabel.setText(growth);
        growthLabel.getStyleClass().removeAll("positive-growth", "negative-growth");
        growthLabel.getStyleClass().add(growth.startsWith("-") ? "negative-growth" : "positive-growth");

        String color = startup.getLogoColor();
        logoBox.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 40;");
        founderBadge.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 25;");

        String initials = startup.getFounder().substring(0, 1).toUpperCase();
        founderInitial.setText(initials);

        insightValueProp.setText(INSIGHTS_VALUE[idx]);
        insightAudience.setText(INSIGHTS_AUDIENCE[idx]);
        insightPricing.setText(INSIGHTS_PRICING[idx]);

        drawGraph(startup.getSparkline());
        loadTags(startup.getTags(), TECH_STACKS[idx]);
        drawActivityGrid();
    }

    private void drawGraph(List<Double> values) {
        graphLine.getPoints().clear();
        if (values == null || values.size() < 2) return;

        // Bind to actual pane width dynamically
        double w = 940.0;
        double h = 140.0;
        double min = Collections.min(values);
        double max = Collections.max(values);
        double range = Math.max(0.0001, max - min);

        for (int i = 0; i < values.size(); i++) {
            double x = (w / (values.size() - 1)) * i;
            double norm = (values.get(i) - min) / range;
            double y = h - (norm * (h - 20)) - 10;
            graphLine.getPoints().addAll(x, y);
        }
    }

    private void loadTags(String tags, String techStack) {
        tagsContainer.getChildren().clear();
        // Category tags
        if (tags != null && !tags.isBlank()) {
            for (String tag : tags.split(",")) {
                Label lbl = new Label(tag.trim());
                lbl.getStyleClass().add("detail-tag");
                tagsContainer.getChildren().add(lbl);
            }
        }
        // Tech stack tags
        for (String tech : techStack.split(",")) {
            Label lbl = new Label(tech.trim());
            lbl.getStyleClass().add("detail-tag-tech");
            tagsContainer.getChildren().add(lbl);
        }
    }

    private void drawActivityGrid() {
        GraphicsContext gc = activityCanvas.getGraphicsContext2D();
        gc.clearRect(0, 0, activityCanvas.getWidth(), activityCanvas.getHeight());
        Random rand = new Random(startup.getId() * 31L);
        int cols = 52, rows = 7;
        double cellW = 14, cellH = 10, gap = 2;
        double startX = 10, startY = 5;
        for (int col = 0; col < cols; col++) {
            for (int row = 0; row < rows; row++) {
                double intensity = rand.nextDouble();
                if (intensity < 0.3) {
                    gc.setFill(Color.web("#1a2535"));
                } else if (intensity < 0.55) {
                    gc.setFill(Color.web("#1e3a4a"));
                } else if (intensity < 0.75) {
                    gc.setFill(Color.web("#1e4d6b"));
                } else {
                    gc.setFill(Color.web("#2563a8"));
                }
                gc.fillRoundRect(
                    startX + col * (cellW + gap),
                    startY + row * (cellH + gap),
                    cellW, cellH, 3, 3
                );
            }
        }
    }

    private void handleBack() {
        if (navigationManager != null && navigationManager.canGoBack()) {
            navigationManager.goBack();
        }
    }
}