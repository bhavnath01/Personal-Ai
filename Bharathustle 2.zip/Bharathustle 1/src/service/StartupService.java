package service;

import model.StartupModel;
import model.DealModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

public class StartupService {
    private static StartupService instance;
    private final ApiClient apiClient;
    private final ObservableList<StartupModel> startups;
    private final List<DealModel> deals;

    private StartupService() {
        this.apiClient = new ApiClient();
        this.startups = FXCollections.observableArrayList();
        this.deals = createMockDeals(); // Deals still mock for now as per task focus
    }

    public static StartupService getInstance() {
        if (instance == null) {
            instance = new StartupService();
        }
        return instance;
    }

    public CompletableFuture<Boolean> signup(String email, String password) {
        return apiClient.signup(email, password);
    }

    public CompletableFuture<Boolean> createStartup(StartupModel startup) {
        return apiClient.createStartup(startup).thenCompose(success -> {
            if (success) {
                return refreshStartups().thenApply(list -> true);
            }
            return CompletableFuture.completedFuture(false);
        });
    }

    public CompletableFuture<List<StartupModel>> refreshStartups() {
        // Trigger background fetch
        apiClient.fetchStartups().thenAccept(newList -> {
            javafx.application.Platform.runLater(() -> {
                startups.setAll(newList);
            });
        });
        
        // Return existing data immediately for speed
        return CompletableFuture.completedFuture(new ArrayList<>(startups));
    }

    public List<StartupModel> getAllStartups() {
        return new ArrayList<>(startups);
    }

    public ObservableList<StartupModel> getStartupsObservable() {
        return startups;
    }

    public List<DealModel> getAllDeals() {
        return new ArrayList<>(deals);
    }

    public StartupModel getStartupById(int id) {
        return startups.stream()
                .filter(s -> s.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public DealModel getDealById(int id) {
        return deals.stream()
                .filter(d -> d.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public void addStartup(StartupModel startup) {
        startups.add(startup);
    }

    public List<StartupModel> searchStartups(String query) {
        if (query == null || query.isBlank()) {
            return getAllStartups();
        }
        String lowerQuery = query.toLowerCase();
        return startups.stream()
                .filter(s -> s.searchText().toLowerCase().contains(lowerQuery))
                .collect(Collectors.toList());
    }

    private List<DealModel> createMockDeals() {
        return Arrays.asList(
                new DealModel(1, "PREMIUM ASSET", "SocialPilot AI", "Automated social media tool", "AI SaaS", "$12,450", "$1.2M", "+22%", "SP", "#163a2b", Arrays.asList(3.0, 4.0, 5.0)),
                new DealModel(2, "DEAL", "EmailGrid Pro", "B2B SaaS seller", "B2B SaaS", "$4,200", "$145k", "+12%", "EG", "#204236", Arrays.asList(1.0, 1.5, 2.0))
        );
    }
}