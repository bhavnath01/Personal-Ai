package service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import model.StartupModel;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

public class ApiClient {
    private static final String BASE_URL = "http://localhost:8080/api";
    private static final String SUPABASE_URL = "https://skkndalcvbvfinamrweb.supabase.co/auth/v1";
    private static final String SUPABASE_KEY = "sb_publishable_x1EEJkKHx8IoLpq0etN0ag_TKcs4bOh";
    
    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;

    public ApiClient() {
        this.httpClient = HttpClient.newHttpClient();
        this.objectMapper = new ObjectMapper();
        this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    public CompletableFuture<Boolean> signup(String email, String password) {
        Map<String, String> body = Map.of("email", email, "password", password);
        try {
            String jsonBody = objectMapper.writeValueAsString(body);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(SUPABASE_URL + "/signup"))
                    .header("apikey", SUPABASE_KEY)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                    .build();

            return httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenApply(response -> {
                        if (response.statusCode() >= 200 && response.statusCode() < 300) {
                            return true;
                        } else {
                            throw new RuntimeException("Signup failed: " + response.body());
                        }
                    });
        } catch (Exception e) {
            return CompletableFuture.failedFuture(e);
        }
    }

    public CompletableFuture<Boolean> createStartup(StartupModel startup) {
        try {
            // Use HashMap because Map.of only supports up to 10 entries
            Map<String, Object> body = new java.util.HashMap<>();
            body.put("name", startup.getName());
            body.put("category", startup.getCategory());
            body.put("description", startup.getDescription());
            body.put("askingPrice", startup.getAskingPrice());
            body.put("website", startup.getWebsite());
            body.put("mrr", startup.getMrr());
            body.put("growth", startup.getGrowth());
            body.put("location", startup.getLocation());
            body.put("founderName", startup.getFounder());
            body.put("logoLetter", startup.getLogoLetter());
            body.put("logoColor", startup.getLogoColor());
            body.put("tags", List.of(startup.getTags().split(", ")));
            body.put("sparkline", startup.getSparkline());

            String jsonBody = objectMapper.writeValueAsString(body);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL + "/startups"))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                    .build();

            return httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenApply(response -> {
                        if (response.statusCode() >= 200 && response.statusCode() < 300) {
                            return true;
                        } else {
                            throw new RuntimeException("Failed to create startup: " + response.body());
                        }
                    });
        } catch (Exception e) {
            return CompletableFuture.failedFuture(e);
        }
    }

    public CompletableFuture<List<StartupModel>> fetchStartups() {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/startups"))
                .GET()
                .build();

        return httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    if (response.statusCode() != 200) {
                        throw new RuntimeException("Failed to fetch startups: " + response.statusCode());
                    }
                    try {
                        List<Map<String, Object>> rawList = objectMapper.readValue(response.body(), new TypeReference<>() {});
                        return rawList.stream().map(this::mapToModel).collect(Collectors.toList());
                    } catch (Exception e) {
                        throw new RuntimeException("Failed to parse JSON", e);
                    }
                });
    }

    private StartupModel mapToModel(Map<String, Object> map) {
        return new StartupModel(
                (Integer) map.getOrDefault("id", 0),
                (String) map.getOrDefault("name", ""),
                (String) map.getOrDefault("category", ""),
                (String) map.getOrDefault("description", ""),
                (String) map.getOrDefault("mrr", ""),
                (String) map.getOrDefault("totalRevenue", ""),
                (String) map.getOrDefault("growth", ""),
                (String) map.getOrDefault("askingPrice", ""),
                (String) map.getOrDefault("website", ""),
                (String) map.getOrDefault("founderName", ""), // Backend uses founderName
                (String) map.getOrDefault("location", ""),
                (String) map.getOrDefault("logoLetter", ""),
                (String) map.getOrDefault("logoColor", ""),
                (List<Double>) map.get("sparkline"),
                formatTags(map.get("tags"))
        );
    }

    private String formatTags(Object tags) {
        if (tags instanceof List) {
            return String.join(", ", (List<String>) tags);
        }
        return (String) tags;
    }
}
