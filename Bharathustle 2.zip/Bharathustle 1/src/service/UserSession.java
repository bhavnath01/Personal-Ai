package service;

public class UserSession {
    private static UserSession instance;

    private String fullName;
    private String email;
    private boolean loggedIn;

    private UserSession() {}

    public static UserSession getInstance() {
        if (instance == null) instance = new UserSession();
        return instance;
    }

    public boolean isLoggedIn() { return loggedIn; }

    public String getFullName() { return fullName; }

    public String getEmail() { return email; }

    /** Returns initials: e.g. "Rahul Sharma" → "RS", "Rahul" → "R" */
    public String getInitials() {
        if (fullName == null || fullName.isBlank()) return "?";
        String[] parts = fullName.trim().split("\\s+");
        if (parts.length == 1) return parts[0].substring(0, 1).toUpperCase();
        return (parts[0].substring(0, 1) + parts[parts.length - 1].substring(0, 1)).toUpperCase();
    }

    public void login(String fullName, String email) {
        this.fullName = fullName;
        this.email = email;
        this.loggedIn = true;
        notifyListeners();
    }

    public void logout() {
        this.fullName = null;
        this.email = null;
        this.loggedIn = false;
        notifyListeners();
    }

    // Simple listener for profile updates
    private Runnable profileUpdateListener;

    public void setProfileUpdateListener(Runnable listener) {
        this.profileUpdateListener = listener;
    }

    private void notifyListeners() {
        if (profileUpdateListener != null) profileUpdateListener.run();
    }
}
