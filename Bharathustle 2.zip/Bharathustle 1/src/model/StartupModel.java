package model;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import java.util.List;

public class StartupModel {
    private final SimpleIntegerProperty id;
    private final StringProperty name;
    private final StringProperty category;
    private final StringProperty description;
    private final StringProperty mrr;
    private final StringProperty totalRevenue;
    private final StringProperty growth;
    private final StringProperty askingPrice;
    private final StringProperty website;
    private final StringProperty founder;
    private final StringProperty location;
    private final StringProperty logoLetter;
    private final StringProperty logoColor;
    private final List<Double> sparkline;
    private final StringProperty tags;

    public StartupModel(
            int id,
            String name,
            String category,
            String description,
            String mrr,
            String totalRevenue,
            String growth,
            String askingPrice,
            String website,
            String founder,
            String location,
            String logoLetter,
            String logoColor,
            List<Double> sparkline,
            String tags) {
        this.id = new SimpleIntegerProperty(id);
        this.name = new SimpleStringProperty(name);
        this.category = new SimpleStringProperty(category);
        this.description = new SimpleStringProperty(description);
        this.mrr = new SimpleStringProperty(mrr);
        this.totalRevenue = new SimpleStringProperty(totalRevenue);
        this.growth = new SimpleStringProperty(growth);
        this.askingPrice = new SimpleStringProperty(askingPrice);
        this.website = new SimpleStringProperty(website);
        this.founder = new SimpleStringProperty(founder);
        this.location = new SimpleStringProperty(location);
        this.logoLetter = new SimpleStringProperty(logoLetter);
        this.logoColor = new SimpleStringProperty(logoColor);
        this.sparkline = sparkline;
        this.tags = new SimpleStringProperty(tags);
    }

    public int getId() { return id.get(); }
    public SimpleIntegerProperty idProperty() { return id; }

    public String getName() { return name.get(); }
    public StringProperty nameProperty() { return name; }

    public String getCategory() { return category.get(); }
    public StringProperty categoryProperty() { return category; }

    public String getDescription() { return description.get(); }
    public StringProperty descriptionProperty() { return description; }

    public String getMrr() { return mrr.get(); }
    public StringProperty mrrProperty() { return mrr; }

    public String getTotalRevenue() { return totalRevenue.get(); }
    public StringProperty totalRevenueProperty() { return totalRevenue; }

    public String getGrowth() { return growth.get(); }
    public StringProperty growthProperty() { return growth; }

    public String getAskingPrice() { return askingPrice.get(); }
    public StringProperty askingPriceProperty() { return askingPrice; }

    public String getWebsite() { return website.get(); }
    public StringProperty websiteProperty() { return website; }

    public String getFounder() { return founder.get(); }
    public StringProperty founderProperty() { return founder; }

    public String getLocation() { return location.get(); }
    public StringProperty locationProperty() { return location; }

    public String getLogoLetter() { return logoLetter.get(); }
    public StringProperty logoLetterProperty() { return logoLetter; }

    public String getLogoColor() { return logoColor.get(); }
    public StringProperty logoColorProperty() { return logoColor; }

    public List<Double> getSparkline() { return sparkline; }

    public String getTags() { return tags.get(); }
    public StringProperty tagsProperty() { return tags; }

    public String searchText() {
        return name.get() + " " + category.get() + " " + mrr.get() + " " + growth.get() + " " + askingPrice.get() + " " + founder.get() + " " + location.get();
    }
}