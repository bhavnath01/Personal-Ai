package model;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import java.util.List;

public class DealModel {
    private final SimpleIntegerProperty id;
    private final StringProperty tag;
    private final StringProperty name;
    private final StringProperty description;
    private final StringProperty detail;
    private final StringProperty mrr;
    private final StringProperty askingPrice;
    private final StringProperty growth;
    private final StringProperty icon;
    private final StringProperty iconColor;
    private final List<Double> sparkline;

    public DealModel(
            int id,
            String tag,
            String name,
            String description,
            String detail,
            String mrr,
            String askingPrice,
            String growth,
            String icon,
            String iconColor,
            List<Double> sparkline) {
        this.id = new SimpleIntegerProperty(id);
        this.tag = new SimpleStringProperty(tag);
        this.name = new SimpleStringProperty(name);
        this.description = new SimpleStringProperty(description);
        this.detail = new SimpleStringProperty(detail);
        this.mrr = new SimpleStringProperty(mrr);
        this.askingPrice = new SimpleStringProperty(askingPrice);
        this.growth = new SimpleStringProperty(growth);
        this.icon = new SimpleStringProperty(icon);
        this.iconColor = new SimpleStringProperty(iconColor);
        this.sparkline = sparkline;
    }

    public int getId() {
        return id.get();
    }

    public SimpleIntegerProperty idProperty() {
        return id;
    }

    public StringProperty tagProperty() {
        return tag;
    }

    public String getTag() {
        return tag.get();
    }

    public StringProperty nameProperty() {
        return name;
    }

    public String getName() {
        return name.get();
    }

    public StringProperty descriptionProperty() {
        return description;
    }

    public String getDescription() {
        return description.get();
    }

    public StringProperty detailProperty() {
        return detail;
    }

    public String getDetail() {
        return detail.get();
    }

    public StringProperty mrrProperty() {
        return mrr;
    }

    public String getMrr() {
        return mrr.get();
    }

    public StringProperty askingPriceProperty() {
        return askingPrice;
    }

    public String getAskingPrice() {
        return askingPrice.get();
    }

    public StringProperty growthProperty() {
        return growth;
    }

    public String getGrowth() {
        return growth.get();
    }

    public StringProperty iconProperty() {
        return icon;
    }

    public String getIcon() {
        return icon.get();
    }

    public StringProperty iconColorProperty() {
        return iconColor;
    }

    public String getIconColor() {
        return iconColor.get();
    }

    public List<Double> getSparkline() {
        return sparkline;
    }

    public String searchText() {
        return tag.get() + " " + name.get() + " " + description.get() + " " + detail.get() + " " + mrr.get() + " " + askingPrice.get();
    }
}