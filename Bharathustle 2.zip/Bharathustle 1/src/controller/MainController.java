package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import javafx.animation.FadeTransition;
import javafx.animation.Interpolator;
import javafx.animation.PauseTransition;
import javafx.animation.ScaleTransition;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Polyline;
import javafx.util.Duration;
import service.NavigationManager;
import service.StartupService;
import model.StartupModel;
import model.DealModel;
import service.UserSession;

public class MainController {
    @FXML
    private ScrollPane contentScrollPane;
    @FXML
    private Pane heroBackgroundPane;
    @FXML
    private TextField heroSearchField;
    @FXML
    private Button addStartupButton;
    @FXML
    private Button heroSearchButton;
    @FXML
    private HBox trendingChipsContainer;
    @FXML
    private FlowPane trendingChipsFlow;
    @FXML
    private HBox metricsContainer;
    @FXML
    private HBox recentlyListedContainer;
    @FXML
    private ScrollPane recentlyScrollPane;
    @FXML
    private Label recentlyLoadingLabel;
    @FXML
    private Label recentlyEmptyLabel;
    @FXML
    private VBox featuredDealCard;
    @FXML
    private Label featuredBadgeLabel;
    @FXML
    private StackPane featuredIconBox;
    @FXML
    private Label featuredIconText;
    @FXML
    private Label featuredNameLabel;
    @FXML
    private Label featuredDescriptionLabel;
    @FXML
    private Label featuredPriceLabel;
    @FXML
    private Label featuredGrowthLabel;
    @FXML
    private Polyline featuredSparkline;
    @FXML
    private Button featuredActionButton;
    @FXML
    private Label featuredLogoTag;
    @FXML
    private VBox bestDealsListContainer;
    @FXML
    private Label bestDealsLoadingLabel;
    @FXML
    private Label bestDealsEmptyLabel;
    @FXML
    private TableView<LeaderboardEntry> leaderboardTable;
    @FXML
    private TableColumn<LeaderboardEntry, Number> rankColumn;
    @FXML
    private TableColumn<LeaderboardEntry, LeaderboardEntry> startupColumn;
    @FXML
    private TableColumn<LeaderboardEntry, String> founderColumn;
    @FXML
    private TableColumn<LeaderboardEntry, String> locationColumn;
    @FXML
    private TableColumn<LeaderboardEntry, String> mrrColumn;
    @FXML
    private TableColumn<LeaderboardEntry, String> growthColumn;
    @FXML
    private Button leaderboardLoadMoreButton;
    @FXML
    private Label navExplore;
    @FXML
    private Label navHowItWorks;
    @FXML private Label navTestimonials;
    @FXML private StackPane profileDot;
    @FXML private Label profileDotLabel;

    private List<StartupListing> allStartups = new ArrayList<>();
    private List<DealListing> allDeals = new ArrayList<>();
    private List<LeaderboardEntry> allLeaderboardRows = new ArrayList<>();
    private boolean initialRenderComplete;
    private StackPane modalContainer;
    private StartupModel lastSelectedStartup;
    private DealModel lastSelectedDeal;


    @FXML
    public void initialize() {
        setupHeroBackground();
        setupMetrics();
        setupTable();
        setupInteractions();
        
        syncProfileIcon();
        UserSession.getInstance().setProfileUpdateListener(this::syncProfileIcon);

        loadDataFromBackend();
    }

    private void loadDataFromBackend() {
        showInitialLoadingState();
        
        // 1. Initial Load (Fast, from cache if available)
        StartupService.getInstance().refreshStartups().thenAccept(startups -> {
            javafx.application.Platform.runLater(() -> {
                populateLocalData(startups);
                applySearchFilter();
            });
        });

        // 2. Setup Listener for background updates (Reactive)
        StartupService.getInstance().getStartupsObservable().addListener((javafx.collections.ListChangeListener<StartupModel>) c -> {
            javafx.application.Platform.runLater(() -> {
                populateLocalData(new ArrayList<>(StartupService.getInstance().getStartupsObservable()));
                applySearchFilter();
            });
        });
    }

    private void populateLocalData(List<StartupModel> startups) {
        allStartups.clear();
        allLeaderboardRows.clear();
        
        for (int i = 0; i < startups.size(); i++) {
            StartupModel sm = startups.get(i);
            
            // Populate Startup Listings
            allStartups.add(new StartupListing(
                sm.getName(), sm.getCategory(), sm.getMrr(), sm.getGrowth(),
                sm.getAskingPrice(), sm.getLogoLetter(), sm.getLogoColor(), sm.getSparkline()
            ));

            // Populate Leaderboard (Top 10 as an example)
            if (i < 10) {
                allLeaderboardRows.add(new LeaderboardEntry(
                    i + 1, sm.getName(), sm.getCategory(), sm.getFounder(),
                    sm.getLocation(), sm.getMrr(), sm.getGrowth(),
                    sm.getLogoLetter(), sm.getLogoColor()
                ));
            }
        }
        
        // Keep mock deals for now as they are not in the startups API
        allDeals = createMockDeals();
    }

    private void syncProfileIcon() {
        if (profileDotLabel != null) {
            UserSession session = UserSession.getInstance();
            profileDotLabel.setText(session.isLoggedIn() ? session.getInitials() : "R");
        }
    }

    private void setupMetrics() {
        metricsContainer.getChildren().clear();
        List<MetricItem> metrics = Arrays.asList(
                new MetricItem("Startups Listed", "2,400+"),
                new MetricItem("Total MRR Verified", "$48M+"),
                new MetricItem("Deals Closed", "340+"),
                new MetricItem("Avg. Deal Multiple", "2.8x"));

        String[] cardClasses = {
            "metric-card-blue",
            "metric-card-cyan",
            "metric-card-purple",
            "metric-card-neutral"
        };
        
        String[] icons = {
            "M 0 4 L 4 0 L 8 4 M 4 0 L 4 12", // Upload / Startups arrow
            "M 0 10 L 4 6 L 8 8 L 14 2", // Graph line for MRR
            "M 0 6 L 6 0 L 12 6 L 6 12 Z", // Diamond for Deals
            "M 0 4 L 4 0 L 8 4 M 4 0 L 4 12" // Arrow for Multiple
        };

        for (int i = 0; i < metrics.size(); i++) {
            MetricItem metric = metrics.get(i);
            
            StackPane cardRoot = new StackPane();
            cardRoot.getStyleClass().addAll("metric-card", cardClasses[i]);
            cardRoot.setPrefSize(172.0, 102.0);
            cardRoot.setMinSize(172.0, 102.0);

            VBox textWrap = new VBox(8.0);
            textWrap.setAlignment(Pos.CENTER_LEFT);
            Label value = new Label(metric.getValue());
            value.getStyleClass().add("metric-value");
            Label label = new Label(metric.getLabel());
            label.getStyleClass().add("metric-label");
            textWrap.getChildren().addAll(value, label);

            javafx.scene.shape.SVGPath icon = new javafx.scene.shape.SVGPath();
            icon.setContent(icons[i]);
            icon.getStyleClass().add("metric-icon");
            icon.setStroke(javafx.scene.paint.Color.web("#ffffff"));
            icon.setStrokeWidth(1.5);
            icon.setFill(javafx.scene.paint.Color.TRANSPARENT);
            icon.setOpacity(0.15);
            
            StackPane.setAlignment(icon, Pos.TOP_RIGHT);
            StackPane.setMargin(icon, new javafx.geometry.Insets(12, 12, 0, 0));
            StackPane.setMargin(textWrap, new javafx.geometry.Insets(0, 0, 0, 16));

            cardRoot.getChildren().addAll(textWrap, icon);
            
            javafx.animation.TranslateTransition lift = new javafx.animation.TranslateTransition(Duration.millis(250), cardRoot);
            ScaleTransition scale = new ScaleTransition(Duration.millis(250), cardRoot);
            
            cardRoot.setOnMouseEntered(e -> {
                cardRoot.pseudoClassStateChanged(javafx.css.PseudoClass.getPseudoClass("hovered"), true);
                lift.setToY(-5.0);
                scale.setToX(1.02);
                scale.setToY(1.02);
                lift.play();
                scale.play();
            });
            
            cardRoot.setOnMouseExited(e -> {
                cardRoot.pseudoClassStateChanged(javafx.css.PseudoClass.getPseudoClass("hovered"), false);
                lift.setToY(0.0);
                scale.setToX(1.0);
                scale.setToY(1.0);
                lift.play();
                scale.play();
            });

            metricsContainer.getChildren().add(cardRoot);
        }
    }

    private void setupHeroBackground() {
        if (heroBackgroundPane == null) return;
        
        java.util.Random rand = new java.util.Random();
        
        // 1. Subtle Nebula Glows (Anchored near top/center where hero is)
        javafx.scene.shape.Circle nebula1 = new javafx.scene.shape.Circle(350);
        nebula1.setFill(javafx.scene.paint.Color.web("#147e9a", 0.08));
        nebula1.setEffect(new javafx.scene.effect.GaussianBlur(140));
        nebula1.layoutXProperty().bind(heroBackgroundPane.widthProperty().multiply(0.4));
        nebula1.layoutYProperty().bind(heroBackgroundPane.heightProperty().multiply(0.2));

        javafx.scene.shape.Circle nebula2 = new javafx.scene.shape.Circle(280);
        nebula2.setFill(javafx.scene.paint.Color.web("#5c3699", 0.06));
        nebula2.setEffect(new javafx.scene.effect.GaussianBlur(120));
        nebula2.layoutXProperty().bind(heroBackgroundPane.widthProperty().multiply(0.6));
        nebula2.layoutYProperty().bind(heroBackgroundPane.heightProperty().multiply(0.3));

        heroBackgroundPane.getChildren().addAll(nebula1, nebula2);

        // 2. Subtle Twinkling Starfield (Full Screen Coverage)
        for (int i = 0; i < 150; i++) { // Increased count for full screen
            double radius = 0.4 + rand.nextDouble() * 1.0;
            javafx.scene.shape.Circle star = new javafx.scene.shape.Circle(radius);
            star.setFill(javafx.scene.paint.Color.WHITE);
            
            // Random distribution over a massive area
            star.setLayoutX(rand.nextDouble() * 3000);
            star.setLayoutY(rand.nextDouble() * 2000);
            double baseOpacity = 0.1 + rand.nextDouble() * 0.3;
            star.setOpacity(baseOpacity);
            
            heroBackgroundPane.getChildren().add(star);

            FadeTransition ft = new FadeTransition(Duration.seconds(3 + rand.nextDouble() * 4), star);
            ft.setFromValue(baseOpacity);
            ft.setToValue(0.02);
            ft.setAutoReverse(true);
            ft.setCycleCount(javafx.animation.Animation.INDEFINITE);
            ft.setDelay(Duration.seconds(rand.nextDouble() * 5));
            ft.play();
        }

        // 3. Slow Floating Particles (Full Screen)
        for (int i = 0; i < 12; i++) { // Increased count
            double radius = 2 + rand.nextDouble() * 3;
            javafx.scene.shape.Circle p = new javafx.scene.shape.Circle(radius);
            p.setFill(javafx.scene.paint.Color.web("#80d0ff", 0.1));
            p.setEffect(new javafx.scene.effect.GaussianBlur(5));
            
            p.setLayoutX(rand.nextDouble() * 2500);
            p.setLayoutY(rand.nextDouble() * 2000);
            heroBackgroundPane.getChildren().add(p);

            javafx.animation.TranslateTransition tt = new javafx.animation.TranslateTransition(Duration.seconds(12 + rand.nextDouble() * 10), p);
            tt.setByY(-180 - rand.nextDouble() * 100);
            tt.setByX(-40 + rand.nextDouble() * 80);
            tt.setAutoReverse(true);
            tt.setCycleCount(javafx.animation.Animation.INDEFINITE);
            tt.setDelay(Duration.seconds(rand.nextDouble() * 4));
            tt.play();
        }
    }

    private void setupTable() {
        leaderboardTable.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        leaderboardTable.setEditable(false);
        leaderboardTable.setFixedCellSize(64);
        leaderboardTable.setRowFactory(table -> new TableRow<>());

        applyFixedColumn(rankColumn, 80.0, "RANK", Pos.CENTER_LEFT, "header-left");
        applyFixedColumn(startupColumn, 260.0, "STARTUP", Pos.CENTER_LEFT, "header-left");
        applyFixedColumn(founderColumn, 220.0, "FOUNDER", Pos.CENTER_LEFT, "header-left");
        applyFixedColumn(locationColumn, 120.0, "LOCATION", Pos.CENTER, "header-center");
        applyFixedColumn(mrrColumn, 140.0, "MRR", Pos.CENTER_RIGHT, "header-right");
        applyFixedColumn(growthColumn, 120.0, "GROWTH %", Pos.CENTER_RIGHT, "header-right");

        rankColumn.setCellValueFactory(data -> data.getValue().rankProperty());
        rankColumn.setCellFactory(column -> new TableCell<>() {
            private final HBox wrap = new HBox();
            private final StackPane badge = new StackPane();
            private final Label value = new Label();

            {
                wrap.setAlignment(Pos.CENTER_LEFT);
                wrap.getStyleClass().add("rank-cell-wrap");

                badge.setPrefSize(30.0, 30.0);
                badge.setMinSize(30.0, 30.0);
                badge.getStyleClass().add("rank-badge");
                value.getStyleClass().add("rank-number");
                badge.getChildren().add(value);
                wrap.getChildren().add(badge);
            }

            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                badge.getStyleClass().removeAll("rank-badge-top1", "rank-badge-top2", "rank-badge-top3");
                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                    return;
                }
                int rank = item.intValue();
                if (rank == 1) {
                    badge.getStyleClass().add("rank-badge-top1");
                } else if (rank == 2) {
                    badge.getStyleClass().add("rank-badge-top2");
                } else if (rank == 3) {
                    badge.getStyleClass().add("rank-badge-top3");
                }
                value.setText(String.format(Locale.US, "%02d", rank));
                setAlignment(Pos.CENTER_LEFT);
                setText(null);
                setGraphic(wrap);
                setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            }
        });

        startupColumn.setCellValueFactory(data -> new ReadOnlyObjectWrapper<>(data.getValue()));
        startupColumn.setCellFactory(column -> new TableCell<>() {
            private LeaderboardRowController controller;
            private Node graphic;

            {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/components/LeaderboardRow.fxml"));
                    graphic = loader.load();
                    controller = loader.getController();
                } catch (IOException exception) {
                    graphic = null;
                    controller = null;
                }
            }

            @Override
            protected void updateItem(LeaderboardEntry item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setGraphic(null);
                    setText(null);
                    return;
                }
                if (controller != null && graphic != null) {
                    controller.setData(item.getStartup(), item.getSector(), item.getLogoLetter(), item.getLogoColor());
                    setText(null);
                    setGraphic(graphic);
                } else {
                    setGraphic(null);
                    setText(item.getStartup());
                }
                setAlignment(Pos.CENTER_LEFT);
                setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            }
        });

        founderColumn.setCellValueFactory(data -> data.getValue().founderProperty());
        founderColumn.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                    return;
                }
                LeaderboardEntry row = getTableRow() == null ? null : getTableRow().getItem();
                if (row == null) {
                    setText(item);
                    setGraphic(null);
                    return;
                }

                HBox founderWrap = new HBox(8.0);
                founderWrap.getStyleClass().add("founder-cell");
                founderWrap.setAlignment(Pos.CENTER_LEFT);
                StackPane founderBadge = new StackPane();
                founderBadge.getStyleClass().add("founder-badge");
                founderBadge.setPrefSize(30.0, 30.0);
                founderBadge.setMinSize(30.0, 30.0);
                Label initial = new Label(row.getFounderInitial());
                initial.getStyleClass().add("founder-badge-text");
                founderBadge.getChildren().add(initial);

                Label founderName = new Label(item);
                founderName.getStyleClass().add("founder-name");
                founderWrap.getChildren().addAll(founderBadge, founderName);

                setAlignment(Pos.CENTER_LEFT);
                setText(null);
                setGraphic(founderWrap);
                setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            }
        });
        locationColumn.setCellValueFactory(data -> data.getValue().locationProperty());
        locationColumn.setCellFactory(column -> new TableCell<>() {
            private final StackPane wrap = new StackPane();
            private final Label value = new Label();

            {
                wrap.getStyleClass().add("value-cell-wrap");
                wrap.prefWidthProperty().bind(widthProperty().subtract(16));
                wrap.getChildren().add(value);
                StackPane.setAlignment(value, Pos.CENTER);
                value.getStyleClass().add("location-cell");
            }

            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                    return;
                }
                value.setText(item);
                setText(null);
                setGraphic(wrap);
                setAlignment(Pos.CENTER);
                setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            }
        });
        mrrColumn.setCellValueFactory(data -> data.getValue().mrrProperty());
        mrrColumn.setCellFactory(column -> new TableCell<>() {
            private final StackPane wrap = new StackPane();
            private final Label value = new Label();

            {
                wrap.getStyleClass().add("value-cell-wrap");
                wrap.prefWidthProperty().bind(widthProperty().subtract(16));
                wrap.getChildren().add(value);
                StackPane.setAlignment(value, Pos.CENTER_RIGHT);
                value.getStyleClass().add("mrr-cell");
            }

            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                    return;
                }
                value.setText(item);
                setText(null);
                setGraphic(wrap);
                setAlignment(Pos.CENTER_RIGHT);
                setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            }
        });
        growthColumn.setCellValueFactory(data -> data.getValue().growthProperty());
        growthColumn.setCellFactory(column -> new TableCell<>() {
            private final StackPane wrap = new StackPane();
            private final Label value = new Label();

            {
                wrap.getStyleClass().add("value-cell-wrap");
                wrap.prefWidthProperty().bind(widthProperty().subtract(16));
                wrap.getChildren().add(value);
                StackPane.setAlignment(value, Pos.CENTER_RIGHT);
                value.getStyleClass().add("growth-value");
            }

            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                    return;
                }
                value.getStyleClass().removeAll("positive-growth", "negative-growth");
                value.getStyleClass().add(item.startsWith("-") ? "negative-growth" : "positive-growth");
                value.setText(item);
                setText(null);
                setGraphic(wrap);
                setAlignment(Pos.CENTER_RIGHT);
                setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            }
        });

        Label placeholder = new Label("No ranked startups match your filter.");
        placeholder.getStyleClass().add("state-label");
        leaderboardTable.setPlaceholder(placeholder);
    }

    private <T> void applyFixedColumn(
            TableColumn<LeaderboardEntry, T> column,
            double width,
            String headerText,
            Pos headerAlignment,
            String headerStyleClass) {
        column.setMinWidth(width);
        column.setPrefWidth(width);
        column.setMaxWidth(width);
        column.setResizable(false);
        column.setSortable(false);
        column.setReorderable(false);

        StackPane headerWrap = new StackPane();
        headerWrap.getStyleClass().add("leaderboard-header-wrap");
        headerWrap.setPrefWidth(width);
        headerWrap.setMinWidth(width);
        headerWrap.setMaxWidth(width);

        Label headerLabel = new Label(headerText);
        headerLabel.getStyleClass().addAll("leaderboard-header-label", headerStyleClass);
        headerWrap.getChildren().add(headerLabel);
        StackPane.setAlignment(headerLabel, headerAlignment);

        column.setText(null);
        column.setGraphic(headerWrap);
    }

    private void setupInteractions() {
        heroSearchButton.setOnAction(event -> {
            String q = heroSearchField.getText();
            NavigationManager nm = NavigationManager.getInstance();
            if (nm != null)
                nm.goToFindStartups(q);
            else
                applySearchFilter();
        });
        heroSearchField.setOnAction(event -> {
            String q = heroSearchField.getText();
            NavigationManager nm = NavigationManager.getInstance();
            if (nm != null)
                nm.goToFindStartups(q);
            else
                applySearchFilter();
        });
        heroSearchField.textProperty().addListener((obs, oldValue, newValue) -> applySearchFilter());

        addStartupButton.setOnAction(event -> showAddStartupModal());
        addHoverScale(addStartupButton, 1.02);
        addHoverScale(heroSearchButton, 1.02);

        setupFeaturedDealClick();
        setupLeaderboardClick();

        addHoverScale(featuredActionButton, 1.02);
        addHoverScale(leaderboardLoadMoreButton, 1.02);

        for (Node chip : trendingChipsFlow.getChildren()) {
            if (chip instanceof Button) {
                addHoverScale(chip, 1.02);
            }
        }

        if (navExplore != null) {
            navExplore.setOnMouseClicked(e -> NavigationManager.getInstance().goToFindStartups(""));
        }
        if (navHowItWorks != null) {
            navHowItWorks.setOnMouseClicked(e -> showHowItWorksModal());
        }
        if (navTestimonials != null) {
            navTestimonials.setOnMouseClicked(e -> NavigationManager.getInstance().goToTestimonials());
        }
        if (profileDot != null) {
            profileDot.setOnMouseClicked(e -> NavigationManager.getInstance().goToAuth());
        }
    }

    private void setupFeaturedDealClick() {
        featuredDealCard.setCursor(Cursor.HAND);
        featuredDealCard.setOnMouseClicked(event -> {
            List<DealListing> deals = resolveDeals();
            if (!deals.isEmpty()) {
                DealListing featured = deals.get(0);
                int dealId = findDealIdByName(featured.getName());
                if (dealId > 0 && NavigationManager.getInstance() != null) {
                    NavigationManager.getInstance().goToDealDetail(dealId);
                }
            }
        });
        addHoverScale(featuredDealCard, 1.02);
    }

    private void setupLeaderboardClick() {
        leaderboardTable.setRowFactory(tableView -> {
            TableRow<LeaderboardEntry> row = new TableRow<>();
            row.setCursor(Cursor.HAND);
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 1 && row.getItem() != null) {
                    LeaderboardEntry entry = row.getItem();
                    String startupName = entry.getStartup();
                    int startupId = findStartupIdByName(startupName);
                    if (startupId > 0 && NavigationManager.getInstance() != null) {
                        NavigationManager.getInstance().goToStartupDetail(startupId);
                    }
                }
            });
            return row;
        });
    }

    private int findStartupIdByName(String name) {
        List<StartupModel> startups = StartupService.getInstance().getAllStartups();
        for (StartupModel s : startups) {
            if (s.getName().equals(name)) {
                return s.getId();
            }
        }
        return 1;
    }

    private int findDealIdByName(String name) {
        List<DealModel> deals = StartupService.getInstance().getAllDeals();
        for (DealModel d : deals) {
            if (d.getName().equals(name)) {
                return d.getId();
            }
        }
        return 1;
    }

    private List<DealListing> resolveDeals() {
        String query = resolveSearchText();
        return allDeals.stream()
                .filter(deal -> matchesQuery(query, deal.searchText()))
                .collect(Collectors.toList());
    }

    private void showHowItWorksModal() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/HowItWorksModal.fxml"));
            Node modal = loader.load();
            HowItWorksModalController controller = loader.getController();
            controller.setParentContainer(getModalContainer());
            controller.showModal();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAddStartupModal() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/AddStartupModal.fxml"));
            Node modal = loader.load();
            service.AddStartupModalController controller = loader.getController();
            controller.setParentContainer(getModalContainer());
            controller.setOnCloseCallback(() -> {
            });
            controller.showModal();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private StackPane getModalContainer() {
        return NavigationManager.getInstance().getViewContainer();
    }

    private void showInitialLoadingState() {
        setVisibleAndManaged(recentlyLoadingLabel, true);
        setVisibleAndManaged(recentlyEmptyLabel, false);
        setVisibleAndManaged(recentlyScrollPane, false);

        setVisibleAndManaged(bestDealsLoadingLabel, true);
        setVisibleAndManaged(bestDealsEmptyLabel, false);
        setVisibleAndManaged(bestDealsListContainer, false);
    }

    private void applySearchFilter() {
        String query = resolveSearchText();

        List<StartupListing> filteredStartups = allStartups.stream()
                .filter(startup -> matchesQuery(query, startup.searchText()))
                .collect(Collectors.toList());
        List<DealListing> filteredDeals = allDeals.stream()
                .filter(deal -> matchesQuery(query, deal.searchText()))
                .collect(Collectors.toList());
        List<LeaderboardEntry> filteredLeaderboard = allLeaderboardRows.stream()
                .filter(row -> matchesQuery(query, row.searchText()))
                .collect(Collectors.toList());

        renderRecentlyListed(filteredStartups);
        renderBestDeals(filteredDeals);
        leaderboardTable.setItems(FXCollections.observableArrayList(filteredLeaderboard));

        if (!initialRenderComplete) {
            fadeInNode(recentlyScrollPane, 70);
            fadeInNode(bestDealsListContainer, 120);
            fadeInNode(leaderboardTable, 180);
            initialRenderComplete = true;
        }
    }

    private String resolveSearchText() {
        String hero = heroSearchField.getText() == null ? "" : heroSearchField.getText().trim();
        return hero.toLowerCase(Locale.US);
    }

    private boolean matchesQuery(String query, String searchable) {
        if (query.isBlank()) {
            return true;
        }
        String normalized = searchable.toLowerCase(Locale.US);
        for (String token : query.split("\\s+")) {
            if (!token.isBlank() && !normalized.contains(token)) {
                return false;
            }
        }
        return true;
    }

    private void renderRecentlyListed(List<StartupListing> startups) {
        recentlyListedContainer.getChildren().clear();
        setVisibleAndManaged(recentlyLoadingLabel, false);

        if (startups.isEmpty()) {
            setVisibleAndManaged(recentlyScrollPane, false);
            setVisibleAndManaged(recentlyEmptyLabel, true);
            return;
        }

        setVisibleAndManaged(recentlyEmptyLabel, false);
        for (StartupListing startup : startups) {
            Node card = loadStartupCard(startup);
            addHoverScale(card, 1.02);
            recentlyListedContainer.getChildren().add(card);
        }
        setVisibleAndManaged(recentlyScrollPane, true);
    }

    private Node loadStartupCard(StartupListing startup) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/components/StartupCard.fxml"));
            Node card = loader.load();
            StartupCardController controller = loader.getController();
            controller.setData(
                    startup.getLogoLetter(),
                    startup.getName(),
                    startup.getCategory(),
                    startup.getMrr(),
                    startup.getGrowth(),
                    startup.getAskingPrice(),
                    startup.getLogoColor(),
                    startup.getSparkline());

            setupStartupCardClick(card, startup.getName());

            return card;
        } catch (IOException exception) {
            VBox fallback = new VBox(4);
            fallback.getStyleClass().add("startup-card");
            Label title = new Label(startup.getName());
            title.getStyleClass().add("card-title");
            Label meta = new Label(startup.getMrr() + " | " + startup.getGrowth());
            meta.getStyleClass().add("card-subtitle");
            fallback.getChildren().addAll(title, meta);

            setupStartupCardClick(fallback, startup.getName());

            return fallback;
        }
    }

    private void setupStartupCardClick(Node card, String startupName) {
        card.setCursor(Cursor.HAND);
        card.setOnMouseClicked(event -> {
            if (event.getClickCount() == 1) {
                int startupId = findStartupIdByName(startupName);
                if (startupId > 0 && NavigationManager.getInstance() != null) {
                    NavigationManager.getInstance().goToStartupDetail(startupId);
                }
            }
        });
    }

    private void renderBestDeals(List<DealListing> deals) {
        bestDealsListContainer.getChildren().clear();
        setVisibleAndManaged(bestDealsLoadingLabel, false);

        if (deals.isEmpty()) {
            setVisibleAndManaged(bestDealsListContainer, false);
            setVisibleAndManaged(bestDealsEmptyLabel, true);
            featuredBadgeLabel.setText("PREMIUM ASSET");
            featuredNameLabel.setText("No Featured Deals");
            featuredDescriptionLabel.setText("Try another search query to reveal verified deal opportunities.");
            featuredIconText.setText("NA");
            featuredIconBox.setStyle("-fx-background-color: rgba(41, 56, 71, 0.75); -fx-background-radius: 14;");
            featuredPriceLabel.setText("$0");
            featuredGrowthLabel.setText("+0%");
            featuredGrowthLabel.getStyleClass().removeAll("positive-growth", "negative-growth");
            featuredGrowthLabel.getStyleClass().add("positive-growth");
            drawFeaturedSparkline(Arrays.asList(0.0, 1.0));
            return;
        }

        setVisibleAndManaged(bestDealsEmptyLabel, false);
        setVisibleAndManaged(bestDealsListContainer, true);

        DealListing featured = deals.get(0);
        featuredBadgeLabel.setText(featured.getTag());
        featuredIconText.setText(featured.getIcon());
        featuredIconBox.setStyle("-fx-background-color: " + featured.getIconColor() + "; -fx-background-radius: 14;");
        featuredNameLabel.setText(featured.getName());
        featuredDescriptionLabel.setText(featured.getDescription());
        featuredPriceLabel.setText(featured.getFeaturedMrr());
        featuredGrowthLabel.setText(featured.getGrowth());
        featuredGrowthLabel.getStyleClass().removeAll("positive-growth", "negative-growth");
        featuredGrowthLabel
                .getStyleClass()
                .add(featured.getGrowth().startsWith("-") ? "negative-growth" : "positive-growth");
        drawFeaturedSparkline(featured.getSparkline());
        if (featuredLogoTag != null) {
            featuredLogoTag.setText(featured.getIcon());
        }

        List<DealListing> rightRailDeals = deals.size() > 1 ? deals.subList(1, deals.size()) : new ArrayList<>();
        for (DealListing deal : rightRailDeals) {
            Node card = loadDealCard(deal);
            addHoverScale(card, 1.02);
            bestDealsListContainer.getChildren().add(card);
        }

        HBox moreDealsRow = new HBox();
        moreDealsRow.getStyleClass().add("deal-more-row");
        Label moreDealsText = new Label("+ See 28 more deals this week");
        moreDealsText.getStyleClass().add("deal-more-text");
        moreDealsRow.getChildren().add(moreDealsText);
        bestDealsListContainer.getChildren().add(moreDealsRow);
    }

    private Node loadDealCard(DealListing deal) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/components/DealCard.fxml"));
            Node card = loader.load();
            DealCardController controller = loader.getController();
            controller.setData(
                    deal.getTag(),
                    deal.getIcon(),
                    deal.getName(),
                    deal.getDetail(),
                    deal.getAskingPrice(),
                    deal.getIconColor());

            setupDealCardClick(card, deal.getName());

            return card;
        } catch (IOException exception) {
            HBox fallback = new HBox();
            fallback.getStyleClass().add("deal-card");
            Label title = new Label(deal.getName() + " - " + deal.getAskingPrice());
            title.getStyleClass().add("deal-name");
            fallback.getChildren().add(title);

            setupDealCardClick(fallback, deal.getName());

            return fallback;
        }
    }

    private void setupDealCardClick(Node card, String dealName) {
        card.setCursor(Cursor.HAND);
        card.setOnMouseClicked(event -> {
            if (event.getClickCount() == 1) {
                int dealId = findDealIdByName(dealName);
                if (dealId > 0 && NavigationManager.getInstance() != null) {
                    NavigationManager.getInstance().goToDealDetail(dealId);
                }
            }
        });
    }

    private void drawFeaturedSparkline(List<Double> values) {
        featuredSparkline.getPoints().clear();
        if (values == null || values.size() < 2) {
            featuredSparkline.setVisible(false);
            return;
        }

        featuredSparkline.setVisible(true);
        double width = 360.0;
        double height = 35.0;
        double min = values.get(0);
        double max = values.get(0);
        for (double value : values) {
            min = Math.min(min, value);
            max = Math.max(max, value);
        }
        double range = Math.max(0.0001, max - min);
        for (int index = 0; index < values.size(); index++) {
            double x = (width / (values.size() - 1)) * index;
            double normalized = (values.get(index) - min) / range;
            double y = height - (normalized * height);
            featuredSparkline.getPoints().addAll(x, y);
        }
    }

    private void addHoverScale(Node node, double hoveredScale) {
        ScaleTransition grow = new ScaleTransition(Duration.millis(180), node);
        grow.setToX(hoveredScale);
        grow.setToY(hoveredScale);
        grow.setInterpolator(Interpolator.EASE_BOTH);

        ScaleTransition settle = new ScaleTransition(Duration.millis(180), node);
        settle.setToX(1.0);
        settle.setToY(1.0);
        settle.setInterpolator(Interpolator.EASE_BOTH);

        node.setOnMouseEntered(event -> {
            settle.stop();
            grow.playFromStart();
        });
        node.setOnMouseExited(event -> {
            grow.stop();
            settle.playFromStart();
        });
    }

    private void fadeInNode(Node node, double delayMillis) {
        if (node == null || !node.isVisible()) {
            return;
        }
        node.setOpacity(0.0);
        FadeTransition fade = new FadeTransition(Duration.millis(360), node);
        fade.setDelay(Duration.millis(delayMillis));
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        fade.setInterpolator(Interpolator.EASE_BOTH);
        fade.play();
    }

    private void setVisibleAndManaged(Node node, boolean visible) {
        node.setVisible(visible);
        node.setManaged(visible);
    }

    private List<StartupListing> createMockStartups() {
        return Arrays.asList(
                new StartupListing(
                        "GrowthSync",
                        "Workflow automation",
                        "$21,200",
                        "+9.4%",
                        "$295,000",
                        "G",
                        "#2e8b57",
                        Arrays.asList(8.0, 9.0, 11.0, 13.0, 15.0, 17.0, 21.0)),
                new StartupListing(
                        "DataFlow AI",
                        "AI analytics",
                        "$44,800",
                        "+7.1%",
                        "$646,400",
                        "D",
                        "#3b82f6",
                        Arrays.asList(18.0, 20.0, 23.0, 25.0, 26.0, 30.0, 33.0)),
                new StartupListing(
                        "ClearLedger",
                        "Fintech infra",
                        "$102,300",
                        "+5.2%",
                        "$1,618,000",
                        "C",
                        "#e879f9",
                        Arrays.asList(32.0, 34.0, 35.0, 36.0, 40.0, 43.0, 46.0)),
                new StartupListing(
                        "FormCraft",
                        "No-code tools",
                        "$29,400",
                        "+8.8%",
                        "$372,000",
                        "F",
                        "#f59e0b",
                        Arrays.asList(11.0, 14.0, 16.0, 15.0, 18.0, 21.0, 24.0)),
                new StartupListing(
                        "ReachPilot",
                        "Sales SaaS",
                        "$91,100",
                        "+2.4%",
                        "$1,211,200",
                        "R",
                        "#ef4444",
                        Arrays.asList(30.0, 31.0, 32.0, 33.0, 34.0, 36.0, 38.0)),
                new StartupListing(
                        "HealthTrackr",
                        "HealthTech",
                        "$68,900",
                        "+6.9%",
                        "$808,000",
                        "H",
                        "#14b8a6",
                        Arrays.asList(22.0, 24.0, 26.0, 27.0, 29.0, 31.0, 34.0)));
    }

    private List<DealListing> createMockDeals() {
        return Arrays.asList(
                new DealListing(
                        "PREMIUM ASSET",
                        "SocialPilot AI",
                        "A fully automated social media management tool with 4,000+ active users and high retention.",
                        "AI SaaS | Verified",
                        "$12,450",
                        "$1,245,000 asking",
                        "+22%",
                        "SP",
                        "#163a2b",
                        Arrays.asList(3.0, 4.0, 4.2, 4.1, 5.1, 5.8, 6.1, 6.8)),
                new DealListing(
                        "DEAL",
                        "EmailGrid Pro",
                        "B2B SaaS seller",
                        "B2B SaaS | $4,200 MRR",
                        "$4,200",
                        "$145,000 asking",
                        "+12%",
                        "EG",
                        "#204236",
                        Arrays.asList(1.0, 1.2, 1.5, 1.9)),
                new DealListing(
                        "DEAL",
                        "DesignStream",
                        "Agency workflow suite",
                        "Agency | $18k MRR",
                        "$18,000",
                        "$420,000 asking",
                        "+8%",
                        "D",
                        "#24384d",
                        Arrays.asList(1.0, 1.3, 1.7, 2.0)),
                new DealListing(
                        "DEAL",
                        "ShopAnalytics",
                        "E-commerce growth stack",
                        "E-commerce SaaS | $9.8k MRR",
                        "$9,800",
                        "$235,000 asking",
                        "+11%",
                        "SA",
                        "#392749",
                        Arrays.asList(1.0, 1.2, 1.6, 1.9)));
    }

    private List<LeaderboardEntry> createLeaderboardRows() {
        return Arrays.asList(
                new LeaderboardEntry(1, "DataPulse", "Analytics SaaS", "Ananya Sharma", "India", "$84,200", "+18.4%",
                        "DP", "#2c445e"),
                new LeaderboardEntry(2, "InvoiceKite", "Finance Automation", "Rohan Mehta", "India", "$62,150",
                        "+12.1%", "IK", "#234638"),
                new LeaderboardEntry(3, "MindMapper AI", "Education Tech", "Siddharth V.", "India", "$45,800", "+34.0%",
                        "MM", "#3f2f57"),
                new LeaderboardEntry(4, "CartMind", "E-commerce SaaS", "Priya Nair", "India", "$38,500", "+9.2%", "CM",
                        "#4f3a29"),
                new LeaderboardEntry(5, "LeadSpark", "B2B Sales Tools", "Vikram Joshi", "India", "$31,200", "-2.3%",
                        "LS", "#41292f"),
                new LeaderboardEntry(6, "HealthTrackr", "HealthTech SaaS", "Meera Pillai", "India", "$28,900", "+21.8%",
                        "HT", "#255057"));
    }

    private static final class MetricItem {
        private final String label;
        private final String value;

        private MetricItem(String label, String value) {
            this.label = label;
            this.value = value;
        }

        private String getLabel() {
            return label;
        }

        private String getValue() {
            return value;
        }
    }

    private static final class StartupListing {
        private final String name;
        private final String category;
        private final String mrr;
        private final String growth;
        private final String askingPrice;
        private final String logoLetter;
        private final String logoColor;
        private final List<Double> sparkline;

        private StartupListing(
                String name,
                String category,
                String mrr,
                String growth,
                String askingPrice,
                String logoLetter,
                String logoColor,
                List<Double> sparkline) {
            this.name = name;
            this.category = category;
            this.mrr = mrr;
            this.growth = growth;
            this.askingPrice = askingPrice;
            this.logoLetter = logoLetter;
            this.logoColor = logoColor;
            this.sparkline = sparkline;
        }

        private String getName() {
            return name;
        }

        private String getCategory() {
            return category;
        }

        private String getMrr() {
            return mrr;
        }

        private String getGrowth() {
            return growth;
        }

        private String getAskingPrice() {
            return askingPrice;
        }

        private String getLogoLetter() {
            return logoLetter;
        }

        private String getLogoColor() {
            return logoColor;
        }

        private List<Double> getSparkline() {
            return sparkline;
        }

        private String searchText() {
            return name + " " + category + " " + mrr + " " + growth + " " + askingPrice;
        }
    }

    private static final class DealListing {
        private final String tag;
        private final String name;
        private final String description;
        private final String detail;
        private final String featuredMrr;
        private final String askingPrice;
        private final String growth;
        private final String icon;
        private final String iconColor;
        private final List<Double> sparkline;

        private DealListing(
                String tag,
                String name,
                String description,
                String detail,
                String featuredMrr,
                String askingPrice,
                String growth,
                String icon,
                String iconColor,
                List<Double> sparkline) {
            this.tag = tag;
            this.name = name;
            this.description = description;
            this.detail = detail;
            this.featuredMrr = featuredMrr;
            this.askingPrice = askingPrice;
            this.growth = growth;
            this.icon = icon;
            this.iconColor = iconColor;
            this.sparkline = sparkline;
        }

        private String getTag() {
            return tag;
        }

        private String getName() {
            return name;
        }

        private String getDescription() {
            return description;
        }

        private String getDetail() {
            return detail;
        }

        private String getFeaturedMrr() {
            return featuredMrr;
        }

        private String getAskingPrice() {
            return askingPrice;
        }

        private String getGrowth() {
            return growth;
        }

        private String getIcon() {
            return icon;
        }

        private String getIconColor() {
            return iconColor;
        }

        private List<Double> getSparkline() {
            return sparkline;
        }

        private String searchText() {
            return tag + " " + name + " " + description + " " + detail + " " + featuredMrr + " " + askingPrice;
        }
    }

    public static class LeaderboardEntry {
        private final IntegerProperty rank = new SimpleIntegerProperty();
        private final StringProperty startup = new SimpleStringProperty();
        private final StringProperty sector = new SimpleStringProperty();
        private final StringProperty founder = new SimpleStringProperty();
        private final StringProperty location = new SimpleStringProperty();
        private final StringProperty mrr = new SimpleStringProperty();
        private final StringProperty growth = new SimpleStringProperty();
        private final StringProperty logoLetter = new SimpleStringProperty();
        private final StringProperty logoColor = new SimpleStringProperty();

        public LeaderboardEntry(
                int rank,
                String startup,
                String sector,
                String founder,
                String location,
                String mrr,
                String growth,
                String logoLetter,
                String logoColor) {
            this.rank.set(rank);
            this.startup.set(startup);
            this.sector.set(sector);
            this.founder.set(founder);
            this.location.set(location);
            this.mrr.set(mrr);
            this.growth.set(growth);
            this.logoLetter.set(logoLetter);
            this.logoColor.set(logoColor);
        }

        public IntegerProperty rankProperty() {
            return rank;
        }

        public StringProperty founderProperty() {
            return founder;
        }

        public StringProperty locationProperty() {
            return location;
        }

        public StringProperty mrrProperty() {
            return mrr;
        }

        public StringProperty growthProperty() {
            return growth;
        }

        public String getStartup() {
            return startup.get();
        }

        public String getSector() {
            return sector.get();
        }

        public String getLogoLetter() {
            return logoLetter.get();
        }

        public String getLogoColor() {
            return logoColor.get();
        }

        public String getFounderInitial() {
            if (founder.get() == null || founder.get().isBlank()) {
                return "?";
            }
            return founder.get().substring(0, 1).toUpperCase(Locale.US);
        }

        private String searchText() {
            return startup.get()
                    + " "
                    + sector.get()
                    + " "
                    + founder.get()
                    + " "
                    + location.get()
                    + " "
                    + mrr.get()
                    + " "
                    + growth.get();
        }
    }
}
