package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;

public class HowItWorksModalController {

    @FXML private StackPane modalRoot;
    @FXML private Button closeButton;
    @FXML private Button ctaButton;

    private StackPane parentContainer;

    public void setParentContainer(StackPane container) {
        this.parentContainer = container;
    }

    @FXML
    public void initialize() {
        closeButton.setOnAction(e -> closeModal());
        ctaButton.setOnAction(e -> closeModal());
        
        // Close on clicking the dark background
        modalRoot.setOnMouseClicked(event -> {
            if (event.getTarget() == modalRoot) {
                closeModal();
            }
        });
    }

    private void closeModal() {
        if (parentContainer != null) {
            parentContainer.getChildren().remove(modalRoot);
        }
    }

    public void showModal() {
        if (parentContainer != null) {
            if (!parentContainer.getChildren().contains(modalRoot)) {
                parentContainer.getChildren().add(modalRoot);
            }
        }
    }
}
