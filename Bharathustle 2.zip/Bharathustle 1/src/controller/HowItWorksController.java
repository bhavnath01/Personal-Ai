package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import service.NavigationManager;
import service.UserSession;

public class HowItWorksController {

    @FXML private Label navExplore;
    @FXML private Label navTestimonials;
    @FXML private Button backButton;
    @FXML private StackPane profileDot;
    @FXML private Label profileDotLabel;

    @FXML
    public void initialize() {
        syncProfileIcon();

        backButton.setOnAction(e -> NavigationManager.getInstance().goBack());

        navExplore.setOnMouseClicked(e ->
                NavigationManager.getInstance().goToFindStartups(""));

        navTestimonials.setOnMouseClicked(e ->
                NavigationManager.getInstance().goToTestimonials());

        profileDot.setOnMouseClicked(e ->
                NavigationManager.getInstance().goToAuth());
    }

    private void syncProfileIcon() {
        UserSession session = UserSession.getInstance();
        profileDotLabel.setText(session.isLoggedIn() ? session.getInitials() : "R");
    }
}
