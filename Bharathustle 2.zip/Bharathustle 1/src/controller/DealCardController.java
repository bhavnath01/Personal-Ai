package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

public class DealCardController {
    @FXML
    private StackPane dealTagBadge;
    @FXML
    private Label dealTagText;
    @FXML
    private StackPane iconBadge;
    @FXML
    private Label iconText;
    @FXML
    private Label startupNameLabel;
    @FXML
    private Label detailLabel;
    @FXML
    private Label askingPriceLabel;

    public void setData(
            String dealTag,
            String icon,
            String startupName,
            String detail,
            String askingPrice,
            String logoBadgeColor) {
        dealTagText.setText(dealTag);
        iconText.setText(icon);
        startupNameLabel.setText(startupName);
        detailLabel.setText(detail);
        askingPriceLabel.setText(askingPrice.replace(" asking", ""));
        dealTagBadge.setStyle(
                "-fx-background-color: rgba(115, 23, 23, 0.38);"
                        + "-fx-border-color: rgba(226, 67, 67, 0.75);"
                        + "-fx-border-width: 1;"
                        + "-fx-background-radius: 14;"
                        + "-fx-border-radius: 14;");
        iconBadge.setStyle("-fx-background-color: " + logoBadgeColor + "; -fx-background-radius: 14;");
    }
}
