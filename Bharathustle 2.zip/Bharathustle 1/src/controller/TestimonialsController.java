package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import service.NavigationManager;
import service.UserSession;

public class TestimonialsController {

    @FXML private Label navExplore;
    @FXML private Label navHowItWorks;
    @FXML private Button backButton;
    @FXML private Button ctaButton;
    @FXML private StackPane profileDot;
    @FXML private Label profileDotLabel;

    @FXML
    public void initialize() {
        syncProfileIcon();

        backButton.setOnAction(e -> NavigationManager.getInstance().goBack());

        navExplore.setOnMouseClicked(e ->
                NavigationManager.getInstance().goToFindStartups(""));

        navHowItWorks.setOnMouseClicked(e ->
                NavigationManager.getInstance().goToHowItWorks());

        profileDot.setOnMouseClicked(e ->
                NavigationManager.getInstance().goToAuth());

        if (ctaButton != null) {
            ctaButton.setOnAction(e ->
                    NavigationManager.getInstance().goToFindStartups(""));
        }
    }

    private void syncProfileIcon() {
        UserSession session = UserSession.getInstance();
        profileDotLabel.setText(session.isLoggedIn() ? session.getInitials() : "R");
    }
}
