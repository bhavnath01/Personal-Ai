package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

public class LeaderboardRowController {
    @FXML
    private StackPane logoCircle;
    @FXML
    private Label logoText;
    @FXML
    private Label startupNameLabel;
    @FXML
    private Label sectorLabel;

    public void setData(String startup, String sector, String logoLetter, String logoColor) {
        startupNameLabel.setText(startup);
        sectorLabel.setText(sector);
        logoText.setText(logoLetter);
        logoCircle.setStyle(
                "-fx-background-color: "
                        + logoColor
                        + "; -fx-background-radius: 20;"
                        + "-fx-border-color: rgba(255,255,255,0.20);"
                        + "-fx-border-width: 1;"
                        + "-fx-border-radius: 20;");
    }
}
