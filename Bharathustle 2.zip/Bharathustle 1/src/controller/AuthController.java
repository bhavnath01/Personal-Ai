package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import service.NavigationManager;
import service.UserSession;
import service.StartupService;

public class AuthController {

    @FXML private Button loginToggle;
    @FXML private Button signupToggle;
    @FXML private VBox loginForm;
    @FXML private VBox signupForm;
    @FXML private TextField loginEmail;
    @FXML private PasswordField loginPassword;
    @FXML private Label loginError;
    @FXML private Button loginButton;
    @FXML private TextField signupName;
    @FXML private TextField signupEmail;
    @FXML private PasswordField signupPassword;
    @FXML private Label signupError;
    @FXML private Button signupButton;
    @FXML private Button backButton;

    @FXML
    public void initialize() {
        loginToggle.setOnAction(e -> showLogin());
        signupToggle.setOnAction(e -> showSignup());
        loginButton.setOnAction(e -> handleLogin());
        signupButton.setOnAction(e -> handleSignup());
        backButton.setOnAction(e -> NavigationManager.getInstance().goBack());
    }

    private void showLogin() {
        loginForm.setVisible(true);
        loginForm.setManaged(true);
        signupForm.setVisible(false);
        signupForm.setManaged(false);
        loginToggle.getStyleClass().setAll("auth-toggle-active");
        signupToggle.getStyleClass().setAll("auth-toggle");
    }

    private void showSignup() {
        loginForm.setVisible(false);
        loginForm.setManaged(false);
        signupForm.setVisible(true);
        signupForm.setManaged(true);
        signupToggle.getStyleClass().setAll("auth-toggle-active");
        loginToggle.getStyleClass().setAll("auth-toggle");
    }

    private void handleLogin() {
        String email = loginEmail.getText();
        String password = loginPassword.getText();

        if (email == null || email.isBlank() || password == null || password.isBlank()) {
            showError(loginError, "Please fill in all fields.");
            return;
        }

        // Simple demo auth: accept any non-empty email/password
        // Use email prefix as name if no name stored
        String name = email.contains("@") ? email.substring(0, email.indexOf("@")) : email;
        // Capitalise first letter
        name = name.substring(0, 1).toUpperCase() + name.substring(1);

        UserSession.getInstance().login(name, email);
        NavigationManager.getInstance().goBack();
    }

    private void handleSignup() {
        String name = signupName.getText();
        String email = signupEmail.getText();
        String password = signupPassword.getText();

        if (name == null || name.isBlank()) {
            showError(signupError, "Please enter your full name.");
            return;
        }
        if (email == null || email.isBlank()) {
            showError(signupError, "Please enter a valid email.");
            return;
        }
        if (password == null || password.length() < 6) {
            showError(signupError, "Password must be at least 6 characters.");
            return;
        }

        signupButton.setDisable(true);
        signupButton.setText("Signing up...");
        signupError.setVisible(false);

        StartupService.getInstance().signup(email.trim(), password)
            .thenAccept(success -> {
                javafx.application.Platform.runLater(() -> {
                    UserSession.getInstance().login(name.trim(), email.trim());
                    NavigationManager.getInstance().goBack();
                });
            })
            .exceptionally(ex -> {
                javafx.application.Platform.runLater(() -> {
                    signupButton.setDisable(false);
                    signupButton.setText("Sign Up");
                    showError(signupError, "Signup failed. Check your connection or email.");
                    ex.printStackTrace();
                });
                return null;
            });
    }

    private void showError(Label errorLabel, String msg) {
        errorLabel.setText(msg);
        errorLabel.setVisible(true);
        errorLabel.setManaged(true);
    }
}
