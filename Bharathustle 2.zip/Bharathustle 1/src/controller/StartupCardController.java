package controller;

import java.util.Collections;
import java.util.List;
import javafx.animation.Interpolator;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Polyline;
import javafx.util.Duration;

public class StartupCardController {
    @FXML
    private VBox cardRoot;
    @FXML
    private Label forSaleBadge;
    @FXML
    private StackPane logoCircle;
    @FXML
    private Label logoText;
    @FXML
    private Label startupNameLabel;
    @FXML
    private Label categoryLabel;
    @FXML
    private Label mrrLabel;
    @FXML
    private Label growthLabel;
    @FXML
    private Label priceLabel;
    @FXML
    private Polyline sparkline;
    @FXML
    private Polygon sparklineFill;

    public void setData(
            String logoLetter,
            String name,
            String category,
            String mrr,
            String growth,
            String price,
            String logoColor,
            List<Double> points) {
        logoText.setText(logoLetter);
        startupNameLabel.setText(name);
        categoryLabel.setText(category);
        mrrLabel.setText(mrr);
        growthLabel.setText(growth);
        priceLabel.setText(price);

        growthLabel.getStyleClass().removeAll("positive-growth", "negative-growth");
        growthLabel.getStyleClass().add(growth.startsWith("-") ? "negative-growth" : "positive-growth");
        logoCircle.setStyle("-fx-background-color: " + logoColor + "; -fx-background-radius: 8;");

        drawSparkline(points);
        setupDynamicStyles(logoColor);
    }

    private void setupDynamicStyles(String hexColor) {
        Color c;
        try {
            c = Color.web(hexColor);
        } catch (Exception e) {
            c = Color.web("#22c55e");
        }

        int r = (int) (c.getRed() * 255);
        int g = (int) (c.getGreen() * 255);
        int b = (int) (c.getBlue() * 255);

        String rgbaBorder = String.format("rgba(%d, %d, %d, 0.45)", r, g, b);
        String rgbaHoverGlow = String.format("rgba(%d, %d, %d, 0.25)", r, g, b);
        String rgbaBadge = String.format("rgba(%d, %d, %d, 0.12)", r, g, b);
        String rgbaGradientStart = String.format("rgba(%d, %d, %d, 0.18)", r, g, b);
        String rgbaHoverGradientStart = String.format("rgba(%d, %d, %d, 0.25)", r, g, b);

        String baseGradient = "radial-gradient(focus-angle 45deg, focus-distance 0%, center 0% 0%, radius 100%, " + rgbaGradientStart + " 0%, #121821 70%)";
        String hoverGradient = "radial-gradient(focus-angle 45deg, focus-distance 0%, center 0% 0%, radius 100%, " + rgbaHoverGradientStart + " 0%, #151d28 80%)";

        String neutralStyle = "-fx-background-color: " + baseGradient + "; -fx-border-color: rgba(255, 255, 255, 0.08); -fx-border-width: 1; -fx-background-radius: 14; -fx-border-radius: 14; -fx-effect: innershadow(gaussian, rgba(255, 255, 255, 0.05), 4, 0, 0, 1);";
        String hoverStyle = "-fx-background-color: " + hoverGradient + "; -fx-border-color: " + rgbaBorder + "; -fx-border-width: 1; -fx-background-radius: 14; -fx-border-radius: 14; -fx-effect: dropshadow(gaussian, " + rgbaHoverGlow + ", 25, 0.2, 0, 0);";

        String fillGradient = "linear-gradient(to bottom, " + String.format("rgba(%d, %d, %d, 0.3)", r, g, b) + " 0%, transparent 100%)";

        cardRoot.setStyle(neutralStyle);
        sparkline.setStroke(c); // Match graph line to theme color immediately
        if (sparklineFill != null) {
            sparklineFill.setStyle("-fx-fill: " + fillGradient + ";");
            sparklineFill.setStroke(Color.TRANSPARENT);
        }
        
        // Permanent tinted badge
        forSaleBadge.setStyle("-fx-border-color: " + rgbaBorder + "; -fx-background-color: " + rgbaBadge + "; -fx-text-fill: white;");

        final Color finalColor = c;
        cardRoot.setOnMouseEntered(e -> {
            cardRoot.setStyle(hoverStyle);
            categoryLabel.setStyle("-fx-text-fill: " + hexColor + ";");
            
            ScaleTransition st = new ScaleTransition(Duration.millis(250), cardRoot);
            st.setToX(1.01);
            st.setToY(1.01);
            st.play();

            TranslateTransition tt = new TranslateTransition(Duration.millis(250), cardRoot);
            tt.setToY(-4);
            tt.play();
        });

        cardRoot.setOnMouseExited(e -> {
            cardRoot.setStyle(neutralStyle);
            categoryLabel.setStyle("");
            
            ScaleTransition st = new ScaleTransition(Duration.millis(250), cardRoot);
            st.setToX(1.0);
            st.setToY(1.0);
            st.play();

            TranslateTransition tt = new TranslateTransition(Duration.millis(250), cardRoot);
            tt.setToY(0);
            tt.play();
        });
    }

    private void drawSparkline(List<Double> values) {
        sparkline.getPoints().clear();
        if (sparklineFill != null) sparklineFill.getPoints().clear();

        if (values == null || values.size() < 2) {
            sparkline.setVisible(false);
            if (sparklineFill != null) sparklineFill.setVisible(false);
            return;
        }

        sparkline.setVisible(true);
        if (sparklineFill != null) sparklineFill.setVisible(true);

        double width = 158.0;
        double height = 18.0;
        double min = Collections.min(values);
        double max = Collections.max(values);
        double range = Math.max(0.0001, max - min);

        if (sparklineFill != null) {
            sparklineFill.getPoints().addAll(0.0, height);
        }

        for (int index = 0; index < values.size(); index++) {
            double x = (width / (values.size() - 1)) * index;
            double normalized = (values.get(index) - min) / range;
            double y = height - (normalized * height);
            sparkline.getPoints().addAll(x, y);
            if (sparklineFill != null) sparklineFill.getPoints().addAll(x, y);
        }

        if (sparklineFill != null) {
            sparklineFill.getPoints().addAll(width, height);
        }
    }
}
