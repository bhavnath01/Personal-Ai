import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import service.NavigationManager;

public class Main extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("/view/main.fxml"));
        StackPane root = loader.load();

        StackPane viewContainer = new StackPane();
        viewContainer.setPrefSize(1400, 960);
        
        NavigationManager.initialize(viewContainer);
        NavigationManager.getInstance().goToHome(root);

        Scene scene = new Scene(viewContainer, 1400, 960);
        scene.getStylesheets().add(Main.class.getResource("/styles/style.css").toExternalForm());

        stage.setTitle("BharatHustle");
        stage.setMinWidth(1200);
        stage.setMinHeight(820);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
